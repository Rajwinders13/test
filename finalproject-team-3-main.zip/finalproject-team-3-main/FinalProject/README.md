# **SleepOnIt**

SleepOnIt is a collaborative painting app that allows up to four people to paint on a shared canvas while on a video call together. 

# **Dependencies**
* C++ 17/20/23
* [SFML](https://www.sfml-dev.org/index.php)
* [CMake](https://cmake.org/)
* [OpenCV](https://docs.opencv.org/4.x/index.html)
* [Nuklear](https://github.com/Immediate-Mode-UI/Nuklear) (include in source files, no need to install).

# **Installation Instructions**
## MacOS:
* Ensure your system has C++ 17 (or above) and [Homebrew](https://brew.sh) installed.
* Download and install the latest distributable version of CMake from their website.
* From your terminal:

    ```txt
    brew update

    brew install sfml opencv 

    cd {into some directory}

    git clone https://github.com/Fall21FSE/finalproject-team-3.git

    cd finalproject-team-3/FinalProject

    mkdir bin

    cd bin

    cmake ..

    make

    ./App
    ```

## Windows:
* Ensure your system has Visual C++ 2019 installed
* You can use either your windows command prompt or Git Bash. Git Bash tends to work better, but if you have a shell that you like, use that instead.
* Download and install the latest distributable version of Cmake from their website. Make sure you add to system PATH when installing.
* Follow the [directions](https://docs.opencv.org/4.x/d3/d52/tutorial_windows_install.html) on OpenCV's website to install OpenCV with git bash. 
* From your git bash:

This is the GNU setup. Not the Microsoft Visual C++ setup.  
This has been tested and works.

Alternative [youtube tutorial playlist](https://youtube.com/playlist?list=PLQMs5svASiXOraccrnEbkd_kVHbAdC2mp) if you don't want to read.

1. **Install required packages with Chocolatey**
    ```txt
    choco install mingw
    choco install cmake
    choco install make
    choco install opencv

    refreshenv
    ```

2. **Add cmake to Windows Environment Variables because of an existing install bug**
    ```txt
    Environment Variables -> User Variables -> New
    Variable Name: cmake
    Variable Path: C:\Program Files\CMake\bin
    ```

3. **Verify that your Environment Variables are recognized** :heavy_check_mark:
    ```txt
    g++ --version
    cmake --version
    make --version
    ```

4. **Manually install SFML as a Chocolatey package**
    ```txt
    git clone https://github.com/jeanmimib/sfml-mingw64.git
    cd sfml-mingw64
    choco pack 
    choco install sfml-mingw64 -s .

    refreshenv
    ```

5. **Add the MinGW64 bin folder to your Windows System Path**
    ```txt
    Environment Variables -> System Variables -> Path -> Edit
    New -> Paste the mingw64 bin folder path

    Hint: You will know it's the correct bin folder if you see several .dll files
    
    My folder path was: C:\ProgramData\chocolatey\lib\mingw\tools\install\mingw64\bin
    ```

6. **Install OpenCV build for MingGW**
    
    Very important!

    [Windows OpenCV](https://opencv.org/releases/) targets the Microsoft Visual C++ (MSVC) compiler by default. This makes it very difficult to cross compile with Mac and Linux. Thus, we want to use an [OpenCV build that targets MinGW](https://github.com/huihut/OpenCV-MinGW-Build) - which is a Windows port of the GCC/G++ compiler.

    1. Download this prebuilt package as a ZIP: https://github.com/huihut/OpenCV-MinGW-Build 

    2. Open the folder and find `x64/mingw`

    3. Copy this `mingw` subfolder

    4. Go to the location of the default OpenCV that was installed with `choco` in step 1
        - My folder path was: `"C:\tools\opencv"`

    5. Navigate into `opencv\build\x64`
        - You should see 2 folders: `vc14 vc15`
    
    6. Paste this `mingw` folder here
        - You should now see 3 folders: `mingw vc14 vc15`
    
    7. Add `mingw\bin` and `mingw\lib` to your Windows System Path
        ```txt
        Environment Variables -> System Variables -> Path -> Edit
        New -> C:\tools\opencv\build\x64\vc15\bin
        New -> C:\tools\opencv\build\x64\vc15\lib
        New -> C:\tools\opencv\build\x64\mingw\bin
        New -> C:\tools\opencv\build\x64\mingw\lib
        ```
    8. Restart your computer. Just do it unless you like to gamble.

7. **Git clone this project**
    
    ```txt
    git clone https://github.com/Fall21FSE/finalproject-team-3.git
    cd finalproject-team-3/FinalProject
    mkdir build
    cd build
    ```
    (The Windows practice is to use a `build` folder rather than `bin`)

8. **Build your C++ project and pray that it works** :pray:
    ```txt
    cd build
    cmake -G "MinGW Makefiles" ..
    make
    ./App.exe
    ```

# Acknowledgements

This Project uses the Nuklear library for GUI elements, the OpenCV library for webcam capture and image processing, and the SFML library for everything else. We did not write this code but we are very grateful to those that did! Also, special thanks to the contributors to the open source project sfml(like the VoIP feature) whose code greatly helped us to integrate the features in our project by building on top of their work.
