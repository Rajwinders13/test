# Planning

The first stage we learned in the software development life cycle is planning. 

1. Take a moment to look through all of the [milestones](./../) and again review the Statement of Work. 
2. Come up with a timeline for completing each of the milestones and post it here.
	- Your Project manager will look through this when completing the first milestone check-in to ensure you have a plan.
3. I also recommend at this time that you set up a channel to communicate with your team members (e.g. teams, slack, email, etc.).

**Fair Warning** Requirements and client needs are subject to change, so do the best you can to plan!

<hr>


## Timeline

- Date: 11/22
	- Functional Assignment 3 Implemented, and ability to communicate sf::Images/Commands over the network
- Date: 11/29
	- Synchronization between server and multiple clients. sf::RenderWindow inside of a GUI
- Date: 12/6
	- Working Video Chat and Clickable toolbars inside of GUI for multiple paint brushes
- Date: 12/12
	- Robust testing framwork and documentation. 
	- Packaged for distribtuion / tested on Linux/Windows. 
