# Milestone Check-in #2

<img src="./media/fort-kent-marker.jpg" align="right" width="300px"/>

## Milestone Check-in with your Project Manager

The final push! You are almost there!

## Milestone ("Sprint") Check list

**Note** Everyone needs to speak at this meeting.

- [x] Has every one had enough tasks to work on?
- [x] What is your plan to finish the project?
- [x] Do you believe you will finish on time?
