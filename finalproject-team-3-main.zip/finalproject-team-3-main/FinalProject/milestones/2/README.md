# Integration

Integrate all of your Assignments 1-4 together amongst your team members into the best version of A4 possible.


Done
