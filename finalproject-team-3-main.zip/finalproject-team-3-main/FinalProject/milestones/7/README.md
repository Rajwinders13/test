# Building Software

- [x] Instructions on how to build your software should be written in this file
	- This is especially important if you have added additional dependencies.
	- Assume someone who has not taken this class (i.e. you on the first day) would have read, build, and run your software from scratch.
- You should have at a minimum in your project
	- [x] A CMakeLists.txt in a root directory
    	- [x] This should generate a 'release' version of your software
  - [x] Run your code with the latest version of cppcheck before commiting your code (could be a github action)
  - [ ] (Optional) Run your code with the latest version of clang-tidy  (could be a github action)

*Modify this file to include instructions on how to build and run your software. Specify which platform you are running on. Running your software involves launching a server and connecting at least 2 clients to the server.*

## Hardware Requirements

1. A client instance **needs** a webcam or the client App will not run.
2. A server instance does not need a webcam since it does not utilize the webcam.

## MacOS Installation

[Tutorial: How to install and use Homebrew for Mac](https://www.digitalocean.com/community/tutorials/how-to-install-and-use-homebrew-on-macos)

```txt
brew update

brew install sfml opencv 

cd {into some directory}

git clone https://github.com/Fall21FSE/finalproject-team-3.git

cd finalproject-team-3/FinalProject

mkdir bin

cd bin

cmake ..

make

./App
```

## Linux Installation

```txt
sudo-apt get update

sudo apt-get install libsfml-dev libopencv-dev python3-opencv

cd {into some directory}

git clone https://github.com/Fall21FSE/finalproject-team-3.git

cd finalproject-team-3/FinalProject

mkdir bin

cd bin

cmake ..

make

./App
```

## Windows Installation

1. **Install required packages with Chocolatey**
    ```txt
    choco install mingw
    choco install cmake
    choco install make
    choco install opencv

    refreshenv
    ```

2. **Add cmake to Windows Environment Variables because of an existing install bug**
    ```txt
    Environment Variables -> User Variables -> New
    Variable Name: cmake
    Variable Path: C:\Program Files\CMake\bin
    ```

3. **Verify that your Environment Variables are recognized** :heavy_check_mark:
    ```txt
    g++ --version
    cmake --version
    make --version
    ```

4. **Manually install SFML as a Chocolatey package**
    ```txt
    git clone https://github.com/jeanmimib/sfml-mingw64.git
    cd sfml-mingw64
    choco pack 
    choco install sfml-mingw64 -s .

    refreshenv
    ```

5. **Add the MinGW64 bin folder to your Windows System Path**
    ```txt
    Environment Variables -> System Variables -> Path -> Edit
    New -> Paste the mingw64 bin folder path

    Hint: You will know it's the correct bin folder if you see several .dll files
    
    My folder path was: C:\ProgramData\chocolatey\lib\mingw\tools\install\mingw64\bin
    ```

6. **Install OpenCV build for MingGW**
    
    Very important!

    [Windows OpenCV](https://opencv.org/releases/) targets the Microsoft Visual C++ (MSVC) compiler by default. This makes it very difficult to cross compile with Mac and Linux. Thus, we want to use an [OpenCV build that targets MinGW](https://github.com/huihut/OpenCV-MinGW-Build) - which is a Windows port of the GCC/G++ compiler.

    1. Download this prebuilt package as a ZIP: https://github.com/huihut/OpenCV-MinGW-Build 

    2. Open the folder and find `x64/mingw`

    3. Copy this `mingw` subfolder

    4. Go to the location of the default OpenCV that was installed with `choco` in step 1
        - My folder path was: `"C:\tools\opencv"`

    5. Navigate into `opencv\build\x64`
        - You should see 2 folders: `vc14 vc15`
    
    6. Paste this `mingw` folder here
        - You should now see 3 folders: `mingw vc14 vc15`
    
    7. Add `mingw\bin` and `mingw\lib` to your Windows System Path
        ```txt
        Environment Variables -> System Variables -> Path -> Edit
        New -> C:\tools\opencv\build\x64\vc15\bin
        New -> C:\tools\opencv\build\x64\vc15\lib
        New -> C:\tools\opencv\build\x64\mingw\bin
        New -> C:\tools\opencv\build\x64\mingw\lib
        ```
    8. Restart your computer. Just do it unless you like to gamble.

7. **Git clone this project**
    
    ```txt
    git clone https://github.com/Fall21FSE/finalproject-team-3.git
    cd finalproject-team-3/FinalProject
    mkdir build
    cd build
    ```
    (The Windows practice is to use a `build` folder rather than `bin`)

8. **Build your C++ project and pray that it works** :pray:
    ```txt
    cd build
    cmake -G "MinGW Makefiles" ..
    make
    ./App.exe
    ```