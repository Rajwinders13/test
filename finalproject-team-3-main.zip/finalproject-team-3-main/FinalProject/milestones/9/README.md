# Testing

- Testing Tasks
  - [x] Make sure there are at least 8 tests written.
  	- At least one test should be networking
	- At least one test should be for your extra feature.
  - [x] Make sure you have a Github action that runs all of your tests on 'push'
  	- That means you will integrate Catch2 into your project, and have the test executable run every time you do a push.
