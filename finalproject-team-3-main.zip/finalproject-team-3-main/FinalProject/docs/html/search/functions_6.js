var searchData=
[
  ['initgui_0',['initGUI',['../class_window_view.html#a65e5be7c86bb58819c765326a36c47be',1,'WindowView']]],
  ['initview_1',['initView',['../class_window_view.html#a773eb4a3ee1a6caab49bdf203d5ff14e',1,'WindowView']]]
];
