var searchData=
[
  ['clear_0',['CLEAR',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0a1e1a4aba20a5a009e616cbc8fad33ac7',1,'PacketType.hpp']]],
  ['client_5fto_5fserver_5finit_1',['CLIENT_TO_SERVER_INIT',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0a3ed4e53a2ea3564ccb9235f9a5251b27',1,'PacketType.hpp']]]
];
