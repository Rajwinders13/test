var searchData=
[
  ['box_5fbuffer_0',['box_buffer',['../_window_view_8cpp.html#a81231e556469a5804a84e4ee5f5f1afb',1,'WindowView.cpp']]],
  ['box_5flen_1',['box_len',['../_window_view_8cpp.html#afdf8dbf82c5881aa5c08b15af6c6addb',1,'WindowView.cpp']]],
  ['buffer_2',['buffer',['../_window_view_8cpp.html#ad5e2d3a85512c52e869f6ad9a4c2808e',1,'WindowView.cpp']]]
];
