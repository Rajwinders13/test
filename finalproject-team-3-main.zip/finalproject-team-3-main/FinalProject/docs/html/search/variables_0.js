var searchData=
[
  ['audio_5flisten_5fport_0',['AUDIO_LISTEN_PORT',['../class_server.html#a407443a888cf941a661ad547b7e0e53f',1,'Server::AUDIO_LISTEN_PORT()'],['../main_8cpp.html#acf2dda1a91a03b5f73b7e19344e161dc',1,'AUDIO_LISTEN_PORT():&#160;main.cpp']]],
  ['audio_5flisten_5freceiver_5fport_1',['AUDIO_LISTEN_RECEIVER_PORT',['../main_8cpp.html#a49215a79d84bacd602f421a67b5de134',1,'main.cpp']]],
  ['audio_5freceive_5flisten_5fport_2',['AUDIO_RECEIVE_LISTEN_PORT',['../class_server.html#a1884036946a329592027f3cd6c6c0fea',1,'Server']]]
];
