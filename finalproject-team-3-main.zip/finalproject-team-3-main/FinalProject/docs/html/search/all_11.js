var searchData=
[
  ['videochat_0',['VideoChat',['../class_video_chat.html',1,'VideoChat'],['../class_video_chat.html#a6ea609c89f879fbc10c62e5b04da364c',1,'VideoChat::VideoChat()']]],
  ['videochat_2ecpp_1',['VideoChat.cpp',['../_video_chat_8cpp.html',1,'']]],
  ['videochat_2ehpp_2',['VideoChat.hpp',['../_video_chat_8hpp.html',1,'']]],
  ['videoreceiveloop_3',['videoReceiveLoop',['../class_controller.html#ac12cf0d8930387b8011afd639d78057c',1,'Controller']]],
  ['viewrunning_4',['viewRunning',['../class_controller.html#ad3181ad1fd1744112f362b3098805c38',1,'Controller']]]
];
