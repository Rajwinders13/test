var searchData=
[
  ['udp_5faudio_0',['UDP_AUDIO',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0ade115dbb58e7515229532c670731e802',1,'PacketType.hpp']]],
  ['udp_5fvideo_1',['UDP_VIDEO',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0a8fdb1fbcc344c49dfc4f918166c9c25e',1,'PacketType.hpp']]]
];
