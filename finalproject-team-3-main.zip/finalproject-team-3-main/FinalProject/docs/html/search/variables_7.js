var searchData=
[
  ['scale_0',['scale',['../class_video_chat.html#a9bc49ea05032b82282a0af223d68ed90',1,'VideoChat']]],
  ['server_5fip_1',['SERVER_IP',['../main_8cpp.html#a8259ca9a2da256541487889c1965d501',1,'main.cpp']]],
  ['serveraudiodata_2',['serverAudioData',['../_audio_stream_receiver_8hpp.html#a73c20d05337e00719712c5ed6d5d8c12',1,'AudioStreamReceiver.hpp']]],
  ['serverendofstream_3',['serverEndOfStream',['../_audio_stream_receiver_8hpp.html#a9124e06a88fe18eba8cfc90c1ea88f54',1,'AudioStreamReceiver.hpp']]],
  ['serverip_4',['serverIP',['../class_controller.html#a0911d640c487ae37e505b2d6907f3ba8',1,'Controller']]]
];
