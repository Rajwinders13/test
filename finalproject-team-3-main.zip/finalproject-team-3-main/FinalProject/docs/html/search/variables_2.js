var searchData=
[
  ['camheight_0',['camHeight',['../class_video_chat.html#aca9858ad85a75a649b0b874fa4aad715',1,'VideoChat']]],
  ['camwidth_1',['camWidth',['../class_video_chat.html#ae84c371cbeed5f6376aa27b0460da84b',1,'VideoChat']]],
  ['canvas_5fheight_2',['CANVAS_HEIGHT',['../main_8cpp.html#a9a6bb856cca6f70949689f0ab3efe40c',1,'main.cpp']]],
  ['canvas_5fwidth_3',['CANVAS_WIDTH',['../main_8cpp.html#a3a92828199777f0837bb46776115c820',1,'main.cpp']]],
  ['clientaudiodata_4',['clientAudioData',['../_audio_stream_recorder_8hpp.html#a74a8f0c2d4489f4574115512e636ee5a',1,'AudioStreamRecorder.hpp']]],
  ['clientendofstream_5',['clientEndOfStream',['../_audio_stream_recorder_8hpp.html#a6a84992b004bcd9409d148ee6de0bb50',1,'AudioStreamRecorder.hpp']]],
  ['color_5fcodes_6',['color_codes',['../class_model.html#a615e895d60946b0c67ebba4e6494866e',1,'Model']]]
];
