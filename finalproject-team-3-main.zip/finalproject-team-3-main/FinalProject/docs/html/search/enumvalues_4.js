var searchData=
[
  ['tcp_5faudio_0',['TCP_AUDIO',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0a7c6fa4bd749ee64f946581dd0d6ca74e',1,'PacketType.hpp']]],
  ['tcp_5fvideo_1',['TCP_VIDEO',['../_packet_type_8hpp.html#a0a80a7bc045affcf10846075b88cbca0a46056cadaa87852bc1c83acf86205de0',1,'PacketType.hpp']]]
];
