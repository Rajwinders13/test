var searchData=
[
  ['popcount_0',['popCount',['../class_controller.html#a6501b34e1082f5b813187c4448559442',1,'Controller']]],
  ['previouscoord_1',['previousCoord',['../class_model.html#a6fd8907bce6fe8c2722232ea73a726ad',1,'Model']]]
];
