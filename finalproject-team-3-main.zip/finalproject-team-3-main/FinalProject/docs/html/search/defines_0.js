var searchData=
[
  ['canvas_5fheight_0',['CANVAS_HEIGHT',['../_controller_8cpp.html#ac8417e7f15a5262562983c1febe9e35e',1,'Controller.cpp']]],
  ['canvas_5fwidth_1',['CANVAS_WIDTH',['../_controller_8cpp.html#aa04ece9d00a940c9b1968887f16faeb3',1,'Controller.cpp']]]
];
