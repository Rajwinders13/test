#include "Controller.hpp"
#include "AudioStreamReceiver.hpp"
#include<thread>

#define CANVAS_WIDTH 1280
#define CANVAS_HEIGHT 720

//Constructor for the Controller. 
Controller::Controller(){
	localIP = sf::IpAddress::getLocalAddress();
	videoUdp.setBlocking(true);
	videoUdp.bind(sf::Socket::AnyPort);
	audioUdp.setBlocking(false);
	audioUdp.bind(sf::Socket::AnyPort);
}

//Destructor.
Controller::~Controller(){}

void Controller::setAudioReceiver(AudioStreamReceiver* audioReceiver){
	m_audioReceiver = audioReceiver;
}

void Controller::setVideoChat(VideoChat* videoChat){
	m_videoChat = videoChat;
}

//attempts to connect to provided IP on listenPort. Returns true if successful, false otherwise. 
bool Controller::connectToServer(sf::IpAddress ip, int listenPort, int audioListenPort, int audioListenReceiverPort){
	std::cout << "============Connecting to Server==========" << std::endl;
	serverIP = ip.toString();
	status = socket.connect(ip, listenPort);
    if(status != sf::Socket::Done){
        std::cout << "Failed to connect to server!" << status << std::endl;
        return false;
    }
	
    std::cout << "============Connected to Server==========" << status << std::endl;
    socket.setBlocking(false);
	audioSocket.setBlocking(false);
	sf::Packet requestPacket;
	std::cout << "Hello server, my name is: " << m_model->m_clientUsername << " from IP address " << localIP.toString()
	<< " listening for video traffic on UDP port " << videoUdp.getLocalPort() << " and audio traffic on UDP port " << audioUdp.getLocalPort() << std::endl;
	requestPacket << sf::Uint8(PacketType::CLIENT_TO_SERVER_INIT) << m_model->m_clientUsername << localIP.toInteger() << videoUdp.getLocalPort() << audioUdp.getLocalPort(); //creates a packet that requests info from the server
	socket.send(requestPacket); //send the packet to the server. 
	
	return true;
}

void Controller::setModel(Model* model){
	m_model = model;
}

void Controller::updateModel(){
	m_mutex.lock();
	m_model->updateModel();
	m_mutex.unlock();
}

void Controller::mouseClicked(sf::Vector2i coordinate){
    // If your mouse is out of bounds, it's a no-op
    if ((coordinate.x < 0) || (coordinate.y < 0) || (coordinate.x >= m_model->getWindowWidth()-1 || (coordinate.y >= m_model->getWindowHeight()-1))) {
        return;
    }
    sf::Vector2i current;
    sf::Vector2i previous;

    // You just started drawing.
    if (m_model->previousCoord == nullptr) { 
        current = coordinate;
        previous = coordinate;
    } else { // You are continuing to draw.
        current = coordinate;
        previous = *m_model->previousCoord;
    }
    // Future improvement: Just push the new pixels directly into the queue, instead of creating a new vector.
    std::vector<std::unique_ptr<SinglePixelCommand>> simulated_line = simulateLine(current, previous, m_model->GetPaintbrushColor(), m_model->GetPaintbrushRadius());
    for (auto& pixel : simulated_line) {
        m_model -> addLocalCommand(std::move(pixel));
    }
    m_model->previousCoord = std::unique_ptr<sf::Vector2i>(new sf::Vector2i(coordinate));
}


// When the mouse is released, push the count to the m_undo_count stack. Reset the count.
void Controller::mouseReleased(sf::Vector2i coordinate){
    if (m_model->drawCount == 0) {
        return;
    }
    m_model->m_undo_count.push(m_model->drawCount);
    std::cout << "Pushed " << m_model->drawCount << " to the undo stack" << std::endl;
    m_model->drawCount = 0;
    m_model->previousCoord = nullptr;
}

// Simulate a thick line and get a vector of SinglePixelCommands.
std::vector<std::unique_ptr<SinglePixelCommand>> Controller::simulateLine(sf::Vector2i& current, sf::Vector2i& previous, sf::Color& color, sf::Uint32& radius) {
    std::vector<std::unique_ptr<SinglePixelCommand>> extractedPixels;

    // A circle template drawn at (0,0)
    std::vector<sf::Vector2i> circle_template = Model::GetCircleTemplate(radius);
    // The circle template shifted by (x,y)
    std::vector<sf::Vector2i> all_current = Model::UseCircleTemplate(current, circle_template);
    std::vector<sf::Vector2i> all_previous = Model::UseCircleTemplate(previous, circle_template);

    // Connect the dots
    for (int i=0; i<all_current.size(); i++) {
        std::vector<sf::Vector2i> intermediate_coords = MathUtility::ExtremelyFastLineAlgo(all_previous[i], all_current[i]);
        for (int j=0; j<intermediate_coords.size(); j++) {
            // std::unique_ptr<SinglePixelCommand> pixel(new SinglePixelCommand(intermediate_coords[j], color));
            std::unique_ptr<SinglePixelCommand> pixel = std::make_unique<SinglePixelCommand>(intermediate_coords[j], color);
            extractedPixels.push_back(std::move(pixel));
        }
    }
    return extractedPixels;
}

//Sends a string packet to the server. 
bool Controller::sendStringToServer(std::string message){
	sf::Packet packet;
	PacketType type = STRING;
	packet << sf::Uint8(type) << message; 
	if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}

//Sends a image packet to the server. 
bool Controller::sendImageToServer(sf::Image image){
	sf::Packet packet;
	PacketType type = IMAGE;
	packet << sf::Uint8(type) << image;
	if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}

//Sends an integer to the server.
bool Controller::sendIntegerToServer(int integer){
	sf::Packet packet;
	PacketType type = INTEGER;
	packet << sf::Uint8(type) << sf::Int32(integer);
	if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}

//Sends a SinglePixelCommand to the server. 
bool Controller::sendSinglePixelCommandToServer(SinglePixelCommand& pixel){
	sf::Packet packet;
	PacketType type = SINGLEPIXELCOMMAND;
	packet << sf::Uint8(type) << pixel;
	if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}

bool Controller::sendBulkCommmandsToServer(std::vector<SinglePixelCommand>& bulkCommands, int numCommands){
    sf::Packet packet;
    PacketType type = BULKCOMMANDS;
    packet << sf::Uint8(type) << sf::Uint32(numCommands);
    for (int i=0; i<numCommands; i++) {
        packet << bulkCommands[i];
    }
    if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}


bool Controller::sendClearCommandToServer(sf::Color newColor){
	sf::Packet packet;
	int r,g,b = 0;
	r = newColor.r;
	g = newColor.g;
	b = newColor.b;
	PacketType type = CLEAR;
	packet << sf::Uint8(type) << r << g << b;
	if(socket.send(packet) == sf::Socket::Done) {
		return true;
	}
	return false;
}

//Get all the pending commands from the model and send them to the server.
//Then, deal with any data that was sent from the server.
void Controller::loop(){
	sf::Clock clock;
	while(viewRunning){
		m_mutex.lock();
        sendCommandData();
		m_mutex.unlock();
		sf::Packet packet;
		if(socket.receive(packet)==sf::Socket::Done) {
			m_mutex.lock();
			parsePacket(packet);
			m_mutex.unlock();
		}
		sf::Time time = clock.getElapsedTime();
			if(time > sf::seconds(0.1)){
				sendVideoData(90);
				clock.restart();
			}
		}
	}

//This loop will run in its own thread to receive video traffic. It modifies the queue 
//m_udpVideoPackets, so any interaction with that queue outside of this function requires
//the m_videoMutex.
void Controller::videoReceiveLoop(){
	sf::IpAddress sender;	
	unsigned short remotePort;
	while(true){
		sf::Packet packet;
		if(videoUdp.receive(packet,sender, remotePort)==sf::Socket::Done){
			m_videoMutex.lock();
			m_udpVideoPackets.push(packet);
			m_videoMutex.unlock();
		}
	}
}


void Controller::sendCommandData() {
    //m_mutex.lock();
    std::queue<std::unique_ptr<Command>> pendingCommands = m_model->getCommandsForServer(); //get the queue of commands that needs to be sent to the server. 
    int byteSize = sizeof(*pendingCommands.front().get());
    int packetCapacity = 50;
    while(!pendingCommands.empty()){
        
        std::vector<SinglePixelCommand> commands_vector;
        commands_vector.reserve(packetCapacity*byteSize);

        // Shove 50 commands into the vector
        if (pendingCommands.size() > packetCapacity) {
            for (int i = 0; i < packetCapacity; i++) {
                SinglePixelCommand command = *dynamic_cast<SinglePixelCommand*>(std::move(pendingCommands.front().get()));
                commands_vector.push_back(command);
                pendingCommands.pop();
            }
            sendBulkCommmandsToServer(commands_vector, packetCapacity);
        }
        else {
            if(sendSinglePixelCommandToServer(*dynamic_cast<SinglePixelCommand*>(std::move(pendingCommands.front()).get()))){}
            pendingCommands.pop();
        }
    }
    //m_mutex.unlock();
}

// void Controller::sendCommandData() {
// 	int packetCapacity = 200;
// 	int numPendingCommands = m_model->getNumPendingCommandsForServer();
// 	if(numPendingCommands == 0){
// 		return;
// 	}
// 	std::queue<std::unique_ptr<Command>> pendingCommands = m_model->getCommandsForServer();
// 	if(pendingCommands.size() >= packetCapacity){
// 		std::vector<SinglePixelCommand> commands_vector;
// 		 for (int i = 0; i < packetCapacity; i++) {
//                 commands_vector.push_back(*dynamic_cast<SinglePixelCommand*>(std::move(pendingCommands.front().get())));
//                 pendingCommands.pop();
//             }
//         sendBulkCommmandsToServer(commands_vector, packetCapacity);
// 		return;
// 	}
// 	else if (!pendingCommands.empty()) {
//         sendSinglePixelCommandToServer(*dynamic_cast<SinglePixelCommand*>(std::move(pendingCommands.front()).get()));
//         pendingCommands.pop();
// 		return;
//     }
// 	else{
// 		return;
// 	}
// }
//this function sends numPackets of UDP packets to the server with video data in them. 
void Controller::sendVideoData(int numPackets){
	for(int i = 0; i < numPackets; i++){
		sf::Packet packet = m_videoChat->getNextPacket();
		sf::IpAddress ip = serverIP;
		unsigned short port = 55001;
		videoUdp.send(packet,ip,port);
		m_packetsSentSinceRefresh++;
	}
}

void Controller::updateBufferedVideoFramesFromPackets(){
	std::queue<sf::Packet> tempVideoQueue;
	m_videoMutex.lock();
	while(!m_udpVideoPackets.empty()){
		sf::Packet packet = m_udpVideoPackets.front();
		m_udpVideoPackets.pop();
		tempVideoQueue.push(packet);
	}
	m_videoMutex.unlock();
	while(!tempVideoQueue.empty()){
		sf::Packet packet = tempVideoQueue.front();
		tempVideoQueue.pop();
		m_videoChat->parsePacket(packet);
	}
}

void Controller::moveVideoBuffersToWindowSprites(){
		m_videoChat->moveVideoBuffersToWindowSprites();
}
//Parse packet expects the first part of every packet to be an integer. It casts that interger into
//The PacketType enum, and then decides how to handle the rest of the data in the packet based on the PacketType. 
void Controller::parsePacket(sf::Packet packet){
	sf::Uint8 type;
	packet >> type;
	if((PacketType)type == STRING){
		std::cout << "STRING PACKET RECIEVED" << std::endl;
		std::string message;
		packet >> message;	
		//handling remote messages from other users
		if(!message.empty()){
			m_model->addChatMessage(message); 
		}
			
		std::cout << message << std::endl;
	}
	else if((PacketType)type == SINGLEPIXELCOMMAND){
		//std::cout << "SINGLE PIXEL PACKET RECEIVED" << std::endl;
        std::unique_ptr<SinglePixelCommand> singlepixel(new SinglePixelCommand());
		packet >> *singlepixel;
		m_model->addRemoteCommand(std::move(singlepixel));
	}
    else if((PacketType)type == BULKCOMMANDS) {
		//std::cout << "BULK PACKET RECIEVED" << std::endl;
        sf::Uint32 numCommands = 0;
        packet >> numCommands;
		
        for (int i = 0; i < numCommands; i++) {
            std::unique_ptr<SinglePixelCommand> singlepixel(new SinglePixelCommand());
            packet >> *singlepixel;
            m_model->addRemoteCommand(std::move(singlepixel));
        }
    }
	else if((PacketType)type == SERVER_TO_CLIENT_INIT){
		std::cout << "Server confirmed connection to client." << std::endl;
	}
	else if((PacketType)type == CLEAR){
		std::cout << "Clear Command recieved from server" << std::endl;
		//Parse the rgb colors from the canvas color 
		sf::Color newCanvasColor;
		int red,green, blue = 0;
		packet >> red >> green >> blue;	
		newCanvasColor.r = red;
		newCanvasColor.g = green;
		newCanvasColor.b = blue;
		//set client canvas to the color received in the CLEAR packet
		m_model->getImage()->create(m_model->getWindowWidth(), m_model->getWindowHeight(),newCanvasColor);
	}
}

void Controller::stopControllerLoop(){
	viewRunning = false;
}

void Controller::zReleased(){
    std::cout << "Z released" << std::endl;
	m_mutex.lock();
	m_model->undoCommand();
	m_mutex.unlock();
}

void Controller::yReleased(){
	std::cout << "Y Released" << std::endl;
	m_mutex.lock();
	m_model->redoCommand();
	m_mutex.unlock();
}

void Controller::rReleased(){
    std::cout<< "Displaying image on server" << std::endl;
	sendImageToServer(*m_model->getImage());
}

void Controller::backspaceReleased(){
	std::cout<< "Released Backspace " << std::endl;
	//buffer.loadFromFile("taunt.wav");
	//sound.setBuffer(buffer);
	//sound.play();
}

void Controller::spacebarPressed(){
	std::cout<< "Pressed spacebar " << std::endl;
	//clear out screen locally with current m_paintbrush_color
	m_model->getImage()->create(m_model->getWindowWidth(), m_model->getWindowHeight(),m_model->GetPaintbrushColor());
	//Send clear packet to server to pass to all clients
	sendClearCommandToServer(m_model->GetPaintbrushColor());
}

sf::Packet& operator >> (sf::Packet& packet, sf::Image& image)
{
		std::vector<sf::Uint8> tmpUint(CANVAS_WIDTH*CANVAS_HEIGHT*4);
		for(int i = 0; i < CANVAS_WIDTH*CANVAS_HEIGHT*4; ++i){
			packet >> tmpUint.at(i);
		}
		sf::Uint8 pixels[(CANVAS_WIDTH*CANVAS_HEIGHT*4)];
		for(int i = 0; i < CANVAS_WIDTH*CANVAS_HEIGHT*4; ++i){
			pixels[i] = tmpUint.at(i);
		}
		sf::Image tmpImg;
		tmpImg.create(CANVAS_WIDTH,CANVAS_HEIGHT, pixels);
		image = tmpImg;
        return packet;
}

sf::Packet& operator << (sf::Packet& packet, const sf::Image& image)
{
        size_t sizeX, sizeY;
        sizeX = image.getSize().x;
        sizeY = image.getSize().y;

        std::vector<sf::Uint8> tmpUint;
        for (int i = 0; i < sizeX * sizeY * 4; ++i)
        {
                tmpUint.push_back(image.getPixelsPtr()[i]);
        }

        for (int i = 0; i < sizeX * sizeY * 4; ++i)
        {
                packet << tmpUint.at(i);
        }

        return packet;
}

sf::Packet& operator >> (sf::Packet& packet, SinglePixelCommand& singlePixel) {
	return packet >> singlePixel.m_packetType >> singlePixel.m_xCoord >> singlePixel.m_yCoord >> singlePixel.m_color >> singlePixel.m_previousColor;
}
sf::Packet& operator << (sf::Packet& packet, const SinglePixelCommand& singlePixel) {
	return packet << singlePixel.m_packetType << singlePixel.m_xCoord << singlePixel.m_yCoord << singlePixel.m_color << singlePixel.m_previousColor;
}


