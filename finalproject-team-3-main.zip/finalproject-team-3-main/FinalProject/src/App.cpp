#include "App.hpp"

//Constructor for app. Creates a model, view, and controller. 
App::App(int canvasWidth, int canvasHeight, std::string ipAddress, int audioListenPort){
	m_model = new Model(canvasWidth,canvasHeight);
	m_videoChat = new VideoChat(m_model->getWindowWidth(),m_model->getWindowHeight(),WEBCAM_WIDTH_OFFSET,WEBCAM_HEIGHT_OFFSET);
	m_controller = new Controller();
	m_view = new WindowView(m_model, m_controller, m_videoChat, WEBCAM_WIDTH_OFFSET);
	m_controller->setModel(m_model);
	m_controller->setVideoChat(m_videoChat);
	audioReceiver = new AudioStreamReceiver();
	audioRecorder = new AudioStreamRecorder(ipAddress, audioListenPort);
	m_controller->setAudioReceiver(audioReceiver);
}

//Asks the controller to try to connect to the server with the provided IP address. She server should be listening on listen port.
void App::connectToServer(sf::IpAddress ip, int listenPort, int audioListenPort, int audioListenReceiverPort){
	if(m_controller->connectToServer(ip, listenPort, audioListenPort, audioListenReceiverPort)){
		std::cout << "Successful connection to server" << std::endl;
	} else{
		std::cout << "Failed to connect to server" << std::endl;
	}
}

//Initializes the program loop to refresh the screen and capture user input. 
void App::startViewLoop(){
	m_view->loop();
}

//Initializes the controller loop. This handles model updates that involve communicating with the server. 
void App::startControllerLoop(){
	m_controller->loop();
}

void App::setUserName(std::string user){

	m_model->m_clientUsername = user;
	m_videoChat->m_clientUsername = user;

}

void App::startVideoReceiver(){
	m_controller->videoReceiveLoop();
}

void App::startAudioRecorder(){
	audioRecorder->connectAudioRecorder();
}

void App::startAudioReceiver(unsigned short port){
	audioReceiver->connectAudioReceiver(port);
}

App::~App() {
	delete m_controller;
	delete m_model;
	delete m_view;
}