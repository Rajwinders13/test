/** 
 *  @file   WindowView.hpp 
 *  @brief  WindowView Class Interface
 *  @author Team Sleep On It
 *  @date   yyyy-dd-mm 
 ***********************************************/

#include "WindowView.hpp"

// NUKLEAR
#define NK_INCLUDE_FIXED_TYPES
#define NK_INCLUDE_STANDARD_IO
#define NK_INCLUDE_STANDARD_VARARGS
#define NK_INCLUDE_DEFAULT_ALLOCATOR
#define NK_INCLUDE_VERTEX_BUFFER_OUTPUT
#define NK_INCLUDE_FONT_BAKING
#define NK_INCLUDE_DEFAULT_FONT
#define NK_IMPLEMENTATION
#define NK_SFML_GL2_IMPLEMENTATION

#include "nuklear.h"
#include "nuklear_sfml_gl2.h"

//nuklear gui variables
char buffer[256];
char text[9][64];
int text_len[9];
char box_buffer[512];
int box_len;

//Constructor for the WindowView. Reserves memory for the window, image, sprite, and texture. 
WindowView::WindowView(Model* model, Controller* controller, VideoChat* videoChat, int webcamWidth){
	m_model = model;
	m_controller = controller;
	m_window = new sf::RenderWindow(sf::VideoMode(m_model->getWindowWidth()+(2*webcamWidth),m_model->getWindowHeight()),"Sleep on It");
	m_window->setVerticalSyncEnabled(true);
    refreshRate = 0;
    m_sprite = new sf::Sprite;
    m_texture = new sf::Texture;
	m_videoChat = videoChat;
 	// //Getting the width and height of the video frames
 	// float dWidth = cap.get(cv::CAP_PROP_FRAME_WIDTH); 
 	// float dHeight = cap.get(cv::CAP_PROP_FRAME_HEIGHT); 
}

//Destructor for the WindowView
WindowView::~WindowView(){
	delete m_sprite; 
	delete m_texture; //destroy texture
	delete m_window; // destroy sfml window
	delete gui_window; // destory nukelar sfml window
	delete ctx;    // destory nuklear context 
	delete bg;    //destory nuklear backgorund color ptr;
	return;
}

//A sprite is a 2d rectangle. Sprites need a texture on top of them in order to display anything. 
//In this function, we create an image of BACKGROUND_COLOR which we then turn into a texture. 
//After we have that texture, we set m_sprite to use that texture for the rest of the program's iteratons.
void WindowView::initView(){
	m_texture->loadFromImage(*m_model->getImage());
	assert(m_texture != nullptr && "m_texture != nullptr");
	m_sprite->setTexture(*m_texture); //Our sprite will always use m_texture as its texture now. 
	assert(m_sprite != nullptr && "m_sprite != nullptr");
}


void WindowView::initGUI(){
	sf::ContextSettings settings(24, 8, 4, 2, 2);
	
	//create window for GUI
	gui_window = new sf::RenderWindow(sf::VideoMode(800,800), "Paint GUI Window",sf::Style::Default,settings);
	gui_window->setVerticalSyncEnabled(true);
  	gui_window->setActive(true);
	glViewport(0, 0, gui_window->getSize().x, gui_window->getSize().y);
	ctx = nk_sfml_init(gui_window); // init nuklear window 
	
	//create and import custom font here
	struct nk_font_atlas *atlas; // import nuklear font for text 
	nk_sfml_font_stash_begin(&atlas);
	struct nk_font *font;
	const char *font_path = "../res/arial.ttf";
	font = nk_font_atlas_add_from_file(atlas, font_path, 22.0f, NULL);
	nk_sfml_font_stash_end();
	//pass custom font to nuklear context
	nk_init_default(ctx, &font->handle);

}


//Update our texture with the image from the model. 
void WindowView::draw(){
    static sf::Clock clock;
	// Refresh rate 30 hz = 0.0333f
    // Refresh rate 60 hz = 0.0166f
    // Refresh rate 90 hz = 0.0111f
    if(clock.getElapsedTime().asSeconds() > 0.0333f) {
        m_texture->loadFromImage(*m_model->getImage());
        clock.restart();
	}
}

void WindowView::GUILoop() {
	//Declare Window event handlers
	int show_menu = nk_true;
    int titlebar = nk_true;
    int border = nk_true;
    int resize = nk_true;
    int movable = nk_true;
    int no_scrollbar = nk_false;
    int scale_left = nk_false;
    static nk_flags window_flags = 0;
    int minimizable = nk_true;
    enum nk_style_header_align header_align = NK_HEADER_RIGHT;
    int show_app_about = nk_false;
	window_flags = 0;

	//Set window event handlers for nuklear context
	ctx->style.window.header.align = header_align;
    if (border) window_flags |= NK_WINDOW_BORDER;
    if (resize) window_flags |= NK_WINDOW_SCALABLE;
    if (movable) window_flags |= NK_WINDOW_MOVABLE;
    if (no_scrollbar) window_flags |= NK_WINDOW_NO_SCROLLBAR;
    if (scale_left) window_flags |= NK_WINDOW_SCALE_LEFT;
    if (minimizable) window_flags |= NK_WINDOW_MINIMIZABLE;

	//Begin Nuklear GUI Loop
    if (nk_begin(ctx, "Paint App GUI", nk_rect(0, 0, 800, 800),
      window_flags))
	{
		//Dropdown for App instructions/Guide
        if (nk_tree_push(ctx, NK_TREE_NODE, "App Guide", NK_MINIMIZED))
        {
            nk_layout_row_dynamic(ctx, 50, 1);
            nk_label(ctx, "Keyboard Instructions:", NK_TEXT_LEFT);
            nk_label(ctx, "Undo - Keyboard Z", NK_TEXT_CENTERED);
			nk_label(ctx, "Redo  - Keyboard Y", NK_TEXT_CENTERED);
			nk_label(ctx, "Clear Screen - Spacebar", NK_TEXT_CENTERED);
			nk_label(ctx, "Save - Keyboard S", NK_TEXT_CENTERED);
			nk_label(ctx, "Display Image On Server - Keyboard R", NK_TEXT_CENTERED);
	
            nk_tree_pop(ctx);
        }

		//Variables for paint brush color selector
		//set pallete color selector to paint on int
		static struct nk_colorf gui_color = {0.0f, 0.0f, 0.0f, 1.0f};
		float red = 0;
		float green = 0;
		float blue = 0;
		red = gui_color.r;
		blue = gui_color.b;
		green = gui_color.g;

        if (nk_tree_push(ctx,NK_TREE_NODE,"Color Pallete", NK_MINIMIZED)) 
		{
		
			//window to select paintbrush color here
			nk_layout_row_dynamic(ctx, 40, 5);
			nk_label(ctx,"Paint Color:", NK_TEXT_LEFT);
			
			nk_layout_row_dynamic(ctx, 200, 1);
			gui_color = nk_color_picker(ctx, gui_color, NK_RGBA);
			nk_layout_row_dynamic(ctx, 25, 1);
			//set current color properties of the selected paintbrush here
			gui_color.r = nk_propertyf(ctx, "#R:", 0, gui_color.r, 1.0f, 0.01f, 0.005f);
			gui_color.g = nk_propertyf(ctx, "#G:", 0, gui_color.g, 1.0f, 0.01f, 0.005f);
			gui_color.b = nk_propertyf(ctx, "#B:", 0, gui_color.b, 1.0f, 0.01f, 0.005f);
			gui_color.a = nk_propertyf(ctx, "#A:", 0, gui_color.a, 1.0f, 0.01f, 0.005f);								
			
			nk_tree_pop(ctx);
			nk_layout_row_dynamic(ctx, 50, 1);
			if (nk_button_label(ctx, "Set Color"))
        	{		
				//set current artist color with each loop
				m_model->setColorFromPallete(red,green,blue);
        	}
        }


		static const float ratio[] = {120, 200};
		nk_flags active;
		nk_layout_row(ctx, NK_STATIC, 100, 2, ratio);
                nk_label(ctx, "Chat:", NK_TEXT_LEFT);	
                nk_layout_row_static(ctx, 400, 600, 1);
                nk_edit_string(ctx, NK_EDIT_BOX, box_buffer, &box_len, 512, nk_filter_default);
				
				//adjust height and width of input box here 
        nk_layout_row_dynamic(ctx,50, 1);
        active = nk_edit_string(ctx, NK_EDIT_FIELD|NK_EDIT_SIG_ENTER, text[7], &text_len[7], 64,  nk_filter_ascii);
        nk_layout_row_dynamic(ctx, 50, 1);
		if (nk_button_label(ctx, "Send Message") ||
            (active & NK_EDIT_COMMITED))
        {	
			text[7][text_len[7]] = '\n';  // add new line before each new message
            sendMessageToServer(text[7], text_len[7]); //push text char array to display box	
			text_len[7] = 0; //reset the input box after sending a message
        }
     
		//Button to save a screen shot of the current canvas
        nk_layout_row_dynamic(ctx, 50, 1);
		if (nk_button_label(ctx, "Save Screen Shot"))
        {		
			saveScreenShot();	
        }
	}

	nk_end(ctx);
}

//THIS LOOP IS THE MAIN PROGRAM LOOP
//initView() will create a sprite with a texture that we can display to the screen.
//sf::Event event will capture user input
//m_window->clear() clears the window so we can redraw it
//draw() will get a new image from the model every 10 cycles and update our sprite with it. 
//m_window->draw() will update the window with whatever our sprite looks like currently.
void WindowView::loop(){
	initView();
	initGUI();
	int itr = 0;
	while(m_window->isOpen() && gui_window->isOpen()){
		sf::Event event;
		//this is capturing events from the sfml Canvas window, not the nuklear window. 
		while(m_window->pollEvent(event)){
			// Our close event.
			if(event.type == sf::Event::Closed){
				m_window->close();
				exit(EXIT_SUCCESS);
			}
            // Check for change paintbrush color keypress
            if(m_model->color_codes.find(event.key.code) != m_model->color_codes.end()) {
                m_model->SetPaintbrushColor(event.key.code);
            }
			if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
				sf::Vector2i coordinate = sf::Mouse::getPosition(*m_window);
				m_controller->mouseClicked(coordinate);
			}
			if(event.type == sf::Event::MouseButtonReleased){
				sf::Vector2i coordinate = sf::Mouse::getPosition(*m_window);
				m_controller->mouseReleased(coordinate);
			}

            if(event.type == sf::Event::KeyPressed) {
                if(event.key.code == sf::Keyboard::Space){
                    m_controller->spacebarPressed();		
                }
            }

			if(event.type==sf::Event::KeyReleased){
                if(event.key.code == sf::Keyboard::Escape){
                    m_window->close();
                    exit(EXIT_SUCCESS);
                }
				if(event.key.code == sf::Keyboard::Z){
					m_controller->zReleased();
				}
				else if(event.key.code == sf::Keyboard::Y){
					m_controller->yReleased();
				}
				else if(event.key.code == sf::Keyboard::Y){
					m_controller->rReleased();
				}
				else if(event.key.code == sf::Keyboard::Backspace){
					m_controller->backspaceReleased();
				}
                else if(event.key.code == sf::Keyboard::S){
					saveScreenShot();	
				}
                // else if(event.key.code == sf::Keyboard::Comma){
                //     m_controller->decreasePaintbrushRadius();
                // }
                // else if(event.key.code == sf::Keyboard::Period){
                //     m_controller->increasePaintbrushRadius();
                // }
			}
		}

		//this is capturing input from the nuklear window, not the SFML window.
		nk_input_begin(ctx);
		while(gui_window->pollEvent(event)){
			
			if(event.type == sf::Event::Closed){
				nk_sfml_shutdown();
				gui_window->close();
				exit(EXIT_SUCCESS);
			}
			
			else if (event.type == sf::Event::KeyReleased){
				std::cout << "key released" << std::endl;
				if(event.key.code == sf::Keyboard::Escape){
                    std::cout <<"clicked escape" << std::endl;
                    nk_sfml_shutdown();
                    gui_window->close();
                    exit(EXIT_SUCCESS);
                }
			}
			//Handle backspace when using chat
			if(event.key.code == sf::Keyboard::Backspace){
                text_len[7] = 0; //clear input box here
			}

			nk_sfml_handle_event(&event);
		}
		//Complete input from nuklear GUI
		nk_input_end(ctx);

		// Display and Draw the nuklear GUI
		GUILoop();

		gui_window->setActive(true);
		gui_window->clear();
        glClear(GL_COLOR_BUFFER_BIT);
		nk_sfml_render(NK_ANTI_ALIASING_ON);
		gui_window->display();

		m_controller->updateModel();  // check if there is new commands to execute
		checkForNewMessages(); //check messages each draw loop that need to be displayed

		//Draw and display SFML canvas
		m_window->setActive(true);
		m_window->clear();
		draw();
		m_videoChat->drawVideoFeed(m_window);
		m_window->draw(*m_sprite);
		m_window->display();

		itr++;
		if(itr == 1) {
			m_controller->updateBufferedVideoFramesFromPackets();
			m_controller->moveVideoBuffersToWindowSprites();
			m_videoChat->loadBufferedImageOfLocalWebcam();
			itr=0;
		}
		//sf::sleep(sf::milliseconds(100));
	}
	nk_sfml_shutdown();
	m_controller->stopControllerLoop();		
}


void WindowView::checkForNewMessages(){
	if(!m_model->m_localChatHistory.empty()){
        std::string newMsg = m_model->m_localChatHistory.front(); //get message from local queue
		m_model->m_localChatHistory.pop(); // pop front value 
		bool result = displayChat(newMsg); //display message
    }
}

bool WindowView::displayChat(std::string msg){
	//convert string to char array
    char * cstr = new char [msg.length()+1];
    strcpy(cstr, msg.c_str());
    memcpy(&box_buffer[box_len], cstr, strlen(cstr)); 
    box_len += strlen(cstr);
	return true;
}

void WindowView::sendMessageToServer(std::string msg, int length){
	//convert message to string fromat 
	std::string string_message = "";
    for (int i = 0; i < length; i++) {
		string_message = string_message + msg[i];        
    }
	string_message +='\n'; //concat a new line at the end of each new message
	string_message +='\n';

    if(!string_message.empty()){
        //display message locally first
		m_model->m_localChatHistory.push("You: "); //Locally displayed message label
	    m_model->m_localChatHistory.push(string_message); //add message to the local history of the client
		m_controller->sendStringToServer(string_message);  //send message to server for all clients
    }


}

void WindowView::saveScreenShot(){
	sf::Image *myScreen = m_model->getImage();
	myScreen->saveToFile("ScreenShot.jpg");
	std::cout << "screen shot saved!" << std::endl;

}



