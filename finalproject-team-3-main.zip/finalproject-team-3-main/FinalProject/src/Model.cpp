#include "Model.hpp"

//Constructor. Creates an sf:Image and initializes it with the dimensons and color specified in
//WINDOW_WIDTH, WINDOW_HEIGHT, and BACKGROUND_COLOR
Model::Model(int canvasWidth, int canvasHeight){
    m_image = new sf::Image();
    CANVAS_WIDTH = canvasWidth;
    CANVAS_HEIGHT = canvasHeight;
 	m_image->create(CANVAS_WIDTH,CANVAS_HEIGHT,BACKGROUND_COLOR);
    m_paintbrush_color = new sf::Color(sf::Color::Black);
    m_paintbrush_radius = new sf::Uint32(3);
    // Color code hashmap
    color_codes = {
        {sf::Keyboard::Num1, sf::Color::Black},
        {sf::Keyboard::Num2, sf::Color::White},
        {sf::Keyboard::Num3, sf::Color::Red},
        {sf::Keyboard::Num4, sf::Color::Green},
        {sf::Keyboard::Num5, sf::Color::Blue},
        {sf::Keyboard::Num6, sf::Color::Yellow},
        {sf::Keyboard::Num7, sf::Color::Magenta},
        {sf::Keyboard::Num8, sf::Color::Cyan}
    };
    // Calculate and cache all the circle templates from radius 3 to radius 15 with step size 2.
    for (int radius = 3; radius <= 15; radius+=2) {
        circle_templates[radius] = MathUtility::BresenhamCircleAlgo(radius);
    }
    previousCoord = nullptr;
}

/**
 * Update the model by executing local commands, remote commands, and sending commands to the server.
 */
void Model::updateModel() {
	// First, execute all local commands that are pending.
	while (!m_localCommands.empty()) {
        bool success = m_localCommands.front() -> execute(m_image);
        if (success) {
            drawCount++;
            std::unique_ptr<Command> c_clone = m_localCommands.front() -> clone();
            m_undo.push(std::move(m_localCommands.front()));
            m_commandsForServer.push(std::move(c_clone));
        }
        m_localCommands.pop();
        clearRedo();
	}
	// Then, execute all remote commands that are pending.
	while (!m_remoteCommands.empty()) {
		bool success = m_remoteCommands.front()->execute(m_image);
        m_remoteCommands.pop();
	}

	// Check for new messages from other clients or changes in the server chat history
	while (!m_serverChatHistory.empty()){
		std::string newMessage = m_serverChatHistory.front(); //get the message at the front of the server chat queue
		m_serverChatHistory.pop(); //pop message from the server queue
		bool success = sendServerMessageToClient(newMessage); //send server message to local chat history of all clients
		if(!success){
			std::cout << "Error displaying server messages" << std::endl;
		}
	}
}

int Model::undoCommand() {
    int num_undo = 0;
    if (!m_undo_count.empty()) {
        // Undo an entire stroke by counting the number of indiv Commands
        num_undo = m_undo_count.top();
        std::cout << "Undoing: " << num_undo << " pixels" << std::endl;
        for (int i = 0; i < num_undo; i++) {
            // Undo either returns a new Command to broadcast out, or it returns nothing
            std::optional<std::unique_ptr<Command>> inverse = m_undo.top() -> undo(m_image);
            if (inverse.has_value()) {
                m_commandsForServer.push(std::move(inverse.value()));
            }
            m_redo.push(std::move(m_undo.top()));
            m_undo.pop();
        }
        m_redo_count.push(num_undo);
        m_undo_count.pop();
    } else {
        std::cout << "There is nothing to undo" << std::endl;
    }
    return num_undo;
}

int Model::redoCommand() {
    int num_redo = 0;
    if (!m_redo_count.empty()) {
        // Redo an entire stroke by counting the number of indiv Commands
        num_redo = m_redo_count.top();
        std::cout << "Redoing: " << num_redo << " pixels" << std::endl;
        for (int i = 0; i < m_redo_count.top(); i++) {
            // Redo either returns a new Command to broadcast out, or it returns nothing
            std::optional<std::unique_ptr<Command>> inverse = m_redo.top() -> redo(m_image);
            if (inverse.has_value()) {
                m_commandsForServer.push(std::move(inverse.value()));
            }
            m_undo.push(std::move(m_redo.top()));
            m_redo.pop();
        }
        m_undo_count.push(num_redo);
        m_redo_count.pop();
    }
    else {
        std::cout << "There is nothing to redo" << std::endl;
    }
    return num_redo;
}

/**
 * Clear the redo stack and m_redo_count.
 */
void Model::clearRedo() {
    int clearCount = 0;
    while (!m_redo.empty()) {
        clearCount++;
        m_redo.pop();
    }
    while (!m_redo_count.empty()) {
        m_redo_count.pop();
    }
    if (clearCount > 0) {
        std::cout << "Cleared " << clearCount << " from the redo stack" << std::endl;
    }
}


void Model::addLocalCommand(std::unique_ptr<Command> c){
	m_localCommands.push(std::move(c));
}

void Model::addRemoteCommand(std::unique_ptr<Command> c){
    m_remoteCommands.push(std::move(c));
}

void Model::addChatMessage(std::string message){
	m_serverChatHistory.push(message);
}

int Model::getNumPendingCommandsForServer(){
    return m_commandsForServer.size();
}

std::queue<std::unique_ptr<Command>> Model::getCommandsForServer(){
    std::queue<std::unique_ptr<Command>> commands;
    int i = 0;
    while(!m_commandsForServer.empty()){
        i++;
        std::unique_ptr<Command> c_clone = m_commandsForServer.front() -> clone();
        commands.push(std::move(c_clone));
        m_commandsForServer.pop();
        if(i >= 200){
            return std::move(commands);
        }
    }
    return std::move(commands);
}

bool Model::sendServerMessageToClient(std::string msg){
	//std::cout << "New Message added to local history" << std::endl;
	if(!msg.empty()){
		std::string tempUser = m_clientUsername;
		std::cout << "New Message Sent From:  " << tempUser << "\n" << std::endl;
		tempUser+=":\n";
		m_localChatHistory.push(tempUser); //send server message to local clients
		m_localChatHistory.push(msg); //send server message to local clients
		return true;
	}
	return false; 
}

void Model::setUserName(std::string username){
	m_clientUsername = username;
}

sf::Color& Model::GetPaintbrushColor() {
    return *m_paintbrush_color;
}

void Model::SetPaintbrushColor(sf::Keyboard::Key numKey) {
    *m_paintbrush_color = color_codes[numKey];
}

sf::Uint32& Model::GetPaintbrushRadius(){
    return *m_paintbrush_radius;
}

void Model::SetPaintbrushRadius(sf::Uint32 radius){
    *m_paintbrush_radius = radius;
}

/**
 * @brief Get a cached circle template given a certain radius.
 */
std::vector<sf::Vector2i> Model::GetCircleTemplate(sf::Uint32& radius) {
    return circle_templates[radius];
}

/**
 * @brief A cached circle template generated at (0,0) which is shifted by (x,y)
 *        rather than constantly computing the same circle.
 */
std::vector<sf::Vector2i> Model::UseCircleTemplate(sf::Vector2i& coord, std::vector<sf::Vector2i>& circle_template) {
    int x0 = coord.x;
    int y0 = coord.y;
	std::vector<sf::Vector2i> transformedCircle;
    // Reserve memory in vector to get 4x performance: https://github.com/facontidavide/CPP_Optimizations_Diary/blob/master/docs/reserve.md 
    transformedCircle.reserve((circle_template.size()*8));
    // Use std::transform to shift the circle template by (x,y)
    std::transform(circle_template.begin(), circle_template.end(), std::back_inserter(transformedCircle),
    	[x0,y0](sf::Vector2i p) {
    		return sf::Vector2i(p.x + x0, p.y + y0);
    	});
    return transformedCircle;
}

//Returns the pointer to the image stored in the model
sf::Image* Model::getImage(){
	return m_image;
}

void Model::setImage(sf::Image* image){
    m_image = image;
}

//Returns the width of the window, measured in number of pixels. 
int Model::getWindowWidth(){
	return CANVAS_WIDTH;
}

//Returns the height of the window, measured in number of pixels. 
int Model::getWindowHeight(){
	return CANVAS_HEIGHT;
}


//Sets the m_paintbrush_color to the specified color in the GUI Pallete
void Model::setColorFromPallete(float red, float green, float blue){
	//convert rgb decimals to whole numbers
	unsigned int redInt = red * 255;
	unsigned int greenInt = green * 255;
	unsigned int blueInt = blue * 255;
	//assign rgb ints to sfml Color object
    m_paintbrush_color->r = redInt;
    m_paintbrush_color->g = greenInt;
    m_paintbrush_color->b = blueInt;
    
}

