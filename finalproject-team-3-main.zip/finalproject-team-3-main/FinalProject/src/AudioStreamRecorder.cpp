#include <AudioStreamRecorder.hpp>
#include <unistd.h>
#include "PacketType.hpp"

AudioStreamRecorder::AudioStreamRecorder(const sf::IpAddress& host, unsigned short port) :
m_host(host),
m_port(port)
{
}


AudioStreamRecorder::~AudioStreamRecorder()
{
    // Make sure to stop the recording thread
    stop();
    sf::sleep(sf::milliseconds(100));
}

bool AudioStreamRecorder::onStart()
{
    if (m_socket.connect(m_host, m_port) == sf::Socket::Done)
    {
        std::cout << "Audio Recorder Connected to server " << m_host << std::endl;
        return true;
    }
    else
    {
        return false;
    }
    return true;
}

bool AudioStreamRecorder::onProcessSamples(const sf::Int16* samples, std::size_t sampleCount)
{   
    // Pack the audio samples into a network packet
    sf::Packet packet;
    PacketType type = TCP_AUDIO;
	packet << clientAudioData;
    packet.append(samples, sampleCount * sizeof(sf::Int16));
    // Send the audio packet to the server
    
    return m_socket.send(packet) == sf::Socket::Done;
}

void AudioStreamRecorder::onStop()
{
    // Send a "end-of-stream" packet
    sf::Packet packet;
    PacketType type = TCP_AUDIO;
	packet << sf::Uint8(type) << clientEndOfStream;
    m_socket.send(packet);
    
    // Close the socket
    //m_socket->disconnect();
}

void AudioStreamRecorder::connectAudioRecorder()
{
    // Check that the device can capture audio
    if (!sf::SoundRecorder::isAvailable())
    {
        std::cout << "Sorry, audio capture is not supported by your system" << std::endl;
        return;
    }
    // Wait for user input...
    // std::cin.ignore(10000, '\n');
    // std::cout << "Press enter to start recording audio";
    // std::cin.ignore(10000, '\n');

    // Start capturing audio data
    start(44100);
    std::cout << "StartAudioRecorder" << std::endl;
    // std::cout << "Recording... press enter to stop";
    // std::cin.ignore(10000, '\n');
    //sf::sleep(sf::milliseconds(100));
    //stop();
}
