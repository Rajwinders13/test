#// Include our Third-Party SFML header
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Network.hpp>             
// Include standard library C++ libraries.
#include <iostream>
#include <string>
#include <string.h> // for memset
#include <future> 
#include "Server.hpp"
#include "Model.hpp"
#include "WindowView.hpp"
#include "Controller.hpp"
#include "App.hpp"
#include <thread>
//Global Variables for Canvas
int CANVAS_WIDTH = 1280;
int CANVAS_HEIGHT = 720;

//Global Variables for client/server.
int LISTEN_PORT = 2001;
int AUDIO_LISTEN_PORT = 2002;
int AUDIO_LISTEN_RECEIVER_PORT = 2003;
std::string SERVER_IP;

//this function will start the controller loop in another thread (different from the view which will run in the main thread.)
//This will allow the controller to communicate with the server without interfering with the view.
void startControllerLoopThread(App* app){
	std::cout<< "Came in controller thread" << std::endl;
	app->connectToServer(sf::IpAddress(SERVER_IP), LISTEN_PORT, AUDIO_LISTEN_PORT, AUDIO_LISTEN_RECEIVER_PORT);
	app->startControllerLoop();
}

void startControllerAudioThread(App* app){
	std::cout<< "Came in audio thread" << std::endl;
	app->startAudioRecorder();
}

void startAudioReceiver(App* app, unsigned short port){
	app->startAudioReceiver(port);
}

void startVideoReceiver(App* app){
	app->startVideoReceiver();
}

std::string user = "";
int main() {
	//Ask the user to be either client or server. 
	std::string role = "undefined";
	std::cout << "Enter (s) for server, enter (c) for client" << std::endl;
	std::cin >> role;
	
	if(role[0]== 's'){
		Server* server = new Server(LISTEN_PORT, AUDIO_LISTEN_PORT, AUDIO_LISTEN_RECEIVER_PORT, CANVAS_WIDTH, CANVAS_HEIGHT); //start a server. It will listen for incoming connections on LISTEN_PORT and have a model of certain dimensions. 
		server->loop();
	}
	else if(role[0] == 'c'){
		std::cout << "Enter a username:" << std::endl;
		std::cin >> user;
		std::cout << "Enter the server I.P. If on own device, 127.0.0.1" << std::endl;
		std::cin.clear();
		std::cin >> SERVER_IP;
		App* app = new App(CANVAS_WIDTH, CANVAS_HEIGHT, SERVER_IP, AUDIO_LISTEN_PORT); //Start a client app. It will create a model with certain dimensions and attempt to connect to a server at SERVER_IP and LISTEN_PORT.
		app->setUserName(user); //pass username to the model here
		//std::thread controllerThread(startControllerLoopThread, app);
		auto controllerThread = std::async(startControllerLoopThread,app);
		auto a = std::async(startControllerAudioThread, app);
		auto b = std::async(startAudioReceiver, app, AUDIO_LISTEN_RECEIVER_PORT);
		auto c = std::async(startVideoReceiver, app);
		app->startViewLoop();
		return 0;
	}
}