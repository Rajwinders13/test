/** 
 *  @file   VideoChat.hpp 
 *  @brief  VideoChat Class Interface
 *  @author Team Sleep On It
 *  @date   yyyy-dd-mm 
 ***********************************************/

#include "VideoChat.hpp"
#include <typeinfo>


VideoChat::VideoChat(int canvasWidth, int canvasHeight, int widthOffset, int heightOffset){
    cap = cv::VideoCapture(0); // the webcam capture object
	//this image is used to create packets with. It is a snapshot of what the webcam was showing
	//at one point
	m_bufferedWebcam.create(camWidth,camHeight,sf::Color::Black);
	//Position the sprites in the correct relative locations
	m_webcamSprite.setPosition(canvasWidth,0);
	//Variables for displaying other people's video feeds.
	//We initialize each image as a 640x360 single color.
	m_bufferedImage1.create(camWidth,camHeight,sf::Color::Black);
	m_remoteImage1.create(camWidth,camHeight,sf::Color::Green);
	m_remoteTexture1.loadFromImage(m_remoteImage1);
	m_remoteSprite1.setTexture(m_remoteTexture1);
	m_remoteSprite1.setScale(scale,scale);
	m_remoteSprite1.setPosition(canvasWidth+widthOffset,0);

	m_bufferedImage2.create(camWidth,camHeight,sf::Color::Black);
	m_remoteImage2.create(camWidth,camHeight,sf::Color::Blue);
	m_remoteTexture2.loadFromImage(m_remoteImage2);
	m_remoteSprite2.setTexture(m_remoteTexture2);
	m_remoteSprite2.setScale(scale,scale);
	m_remoteSprite2.setPosition(canvasWidth,heightOffset);

	m_bufferedImage3.create(camWidth,camHeight,sf::Color::Black);
	m_remoteImage3.create(camWidth,camHeight,sf::Color::Red);
	m_remoteTexture3.loadFromImage(m_remoteImage3);
	m_remoteSprite3.setTexture(m_remoteTexture3);
	m_remoteSprite3.setScale(scale,scale);
	m_remoteSprite3.setPosition(canvasWidth+widthOffset,heightOffset);
	
}
//Fills a UDP packet with:
//Packet Header << clientID << row number << 640 sequential color values
//increments row to the next value
//If we've completed 360 rows, reloads a new image into webcam buffer and resets the current row to 0. 
sf::Packet VideoChat::getNextPacket(){
	sf::Packet packet;
	PacketType type = UDP_VIDEO;
	std::string clientId = m_clientUsername;
	sf::Uint16 currentRow = m_currentRow;
	packet << sf::Uint8(type) << clientId << currentRow; //load in header, clientID, current row
	for(int i = 0; i < camWidth; i++) { //load in the colors of every pixel in that row. 
		packet << m_bufferedWebcam.getPixel(i,m_currentRow).toInteger();
	}
	m_currentRow = m_currentRow + 1; //if we've done all 360 rows in an image, return to the first row. 
	if (m_currentRow == camHeight) {
		m_currentRow = 0;
	}
	return packet; 
}

sf::Packet VideoChat::getTcpPacket(){
	sf::Packet packet;
	sf::Uint8 type = sf::Uint8(TCP_VIDEO);
	std::string clientId = m_clientUsername;
	packet << type << clientId;
    std::vector<sf::Uint8> tmpUint;
    for (int i = 0; i < camWidth * camHeight * 4; ++i){
        tmpUint.push_back(m_bufferedWebcam.getPixelsPtr()[i]);
    }
	for (int i = 0; i < camWidth * camHeight* 4; ++i){
        packet << tmpUint.at(i);
    }
	return packet;
}

//changes the buffered webcam image to the one currently being captured by the webcam.
//The buffered webcam image is used to create packets with. The non buffered webcam image is constantly
//being changed by the camera and is constantly being displayed to the screen.
void VideoChat::loadBufferedImageOfLocalWebcam(){
	m_bufferedWebcam.create(camWidth,camHeight,m_webcamImage.getPixelsPtr());
}

//The buffered images have been being altered by the parse packet function. This
//function takes those buffered images and puts them into a sprite which can be
//drawn on the screen. 
void VideoChat::moveVideoBuffersToWindowSprites(){
	m_remoteImage1.create(camWidth,camHeight,m_bufferedImage1.getPixelsPtr());
	m_remoteTexture1.loadFromImage(m_remoteImage1);
	m_remoteSprite1.setTexture(m_remoteTexture1);

	m_remoteImage2.create(camWidth,camHeight,m_bufferedImage2.getPixelsPtr());
	m_remoteTexture2.loadFromImage(m_remoteImage2);
	m_remoteSprite2.setTexture(m_remoteTexture2);

	m_remoteImage3.create(camWidth,camHeight,m_bufferedImage3.getPixelsPtr());
	m_remoteTexture3.loadFromImage(m_remoteImage3);
	m_remoteSprite3.setTexture(m_remoteTexture3);
}

void VideoChat::parsePacket(sf::Packet& packet){
	sf::Uint8 header;
	std::string clientId;
	sf::Uint16 currentRow;
	packet >> header >> clientId;
	//std::cout << (int) header << clientId;
	if((PacketType)header == TCP_VIDEO){
		std::vector<sf::Uint8> tmpUint(camWidth*camHeight*4);
		for(int i = 0; i < camWidth * camHeight*4; ++i){
			packet >> tmpUint.at(i);
		}
		sf::Uint8 pixels[(camWidth*camHeight*4)];
		for(int i = 0; i < camWidth*camHeight*4; ++i){
			pixels[i] = tmpUint.at(i);
		}
		sf::Image tmpImg;
		tmpImg.create(camWidth,camHeight,pixels);
		if(m_client1Name == "empty"){
			m_client1Name = clientId;
			m_bufferedImage1 = tmpImg;
			return;
		}
		else if(m_client1Name == clientId){
			m_bufferedImage1 = tmpImg;
			return;
		}
		else if(m_client2Name == "empty"){
			m_client2Name = clientId;
			m_bufferedImage2 = tmpImg;
			return;
		}
		else if(m_client2Name == clientId){
			m_bufferedImage2 = tmpImg;
			return;
		}
		else if(m_client3Name == "empty"){
			m_client3Name = clientId;
			m_bufferedImage3 = tmpImg;
			return;
		}
		else if(m_client3Name == clientId){
			m_bufferedImage3 = tmpImg;
			return;
		}		
	}
	
	if((PacketType)header == UDP_VIDEO) {
		packet >> currentRow;
		//std::cout << "Updating buffered images at row " << (int)currentRow << std::endl;
		if(m_client1Name == "empty"){ //if remote client 1 has an empty name field, then this packet is the first new connecton
			m_client1Name = clientId; //set the name of remoteclient1 to the namei in this packet
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage1.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
		else if(m_client1Name == clientId){ //if the name in the packet is the same as the name of remote client 1.
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage1.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
		else if(m_client2Name == "empty"){ //if remote client 2 has an empty name field, then this packet is the second new connecton
			m_client2Name = clientId; //set the name of remoteclient2 to the name in this packet
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage2.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
		else if(m_client2Name == clientId){ //if the name in the packet is the same as the name of remote client 2.
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage2.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
		else if(m_client3Name == "empty"){ //if remote client 3 has an empty name field, then this packet is the third and final new connecton
			m_client3Name = clientId; //set the name of remoteclient3 to the name in this packet
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage3.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
		else if(m_client3Name == clientId){ //if the name in the packet is the same as the name of remote client 3.
			for(int i = 0; i < camWidth; i++){ //update the pixels.
				sf::Uint32 color;
				packet >> color;
				m_bufferedImage3.setPixel(i,currentRow,sf::Color(color));
			}
			return;
		}
	}
}

//Draws the sprites of the images to the screen. 
void VideoChat::drawVideoFeed(sf::RenderWindow* window){
	cap >> m_cameraFrame;
	cv::Mat compressedImage;
	cv::resize(m_cameraFrame,compressedImage,cv::Size(camWidth,camHeight), cv::INTER_LINEAR);
	if(!compressedImage.empty()) {
		cv::cvtColor(compressedImage, m_sfml_rgba_frame, cv::COLOR_BGR2RGBA);
		m_webcamImage.create(m_sfml_rgba_frame.cols, m_sfml_rgba_frame.rows, m_sfml_rgba_frame.ptr());
		if(m_webcamTexture.loadFromImage(m_webcamImage)){
			m_webcamSprite.setTexture(m_webcamTexture);
			m_webcamSprite.setScale(scale,scale);
		}
	}
	window->draw(m_webcamSprite);
	window->draw(m_remoteSprite1);
	window->draw(m_remoteSprite2);
	window->draw(m_remoteSprite3);
}
