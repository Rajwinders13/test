#include "Server.hpp"

//Constructor. Get the TCP listener listening on LISTEN_PORT and add that listener to the selector. 
//Sets up a model/view/controller for the server.
Server::Server(int listenPort, int audioListenPort, int audioRecieverListenPort, int canvasWidth, int canvasHeight){
	LISTEN_PORT = listenPort; //the port we listen for incoming connections on. 
	AUDIO_LISTEN_PORT = audioListenPort;
	AUDIO_RECEIVE_LISTEN_PORT = audioRecieverListenPort;
	CANVAS_WIDTH = canvasWidth;
	CANVAS_HEIGHT = canvasHeight;
	listener.listen(LISTEN_PORT);
	audioListener.listen(AUDIO_LISTEN_PORT);
	std::cout << "Server is listening for new clients on ip: " << sf::IpAddress::getLocalAddress() << " and port " << LISTEN_PORT << " for normal connections and at  " << AUDIO_LISTEN_PORT << " for audio connections." << std::endl;
	selector.add(listener); //add the listener to the socket selector. 
	selector.add(audioListener);
	serverModel = new Model(CANVAS_WIDTH, CANVAS_HEIGHT);
	udp.bind(55001); // listen for UDP packet on port 55001
	udp.setBlocking(false); //dont let this port block the server thread
	selector.add(udp); //add the UDP port to our selector. 
}

Server::~Server() {
    delete serverModel;
    delete serverView;
    delete serverController;
}

//Parse packet expects the first part of every packet to be an integer. It casts that interger into
//The PacketType enum, and then decides how to handle the rest of the data in the packet based on the PacketType. 
void Server::parsePacket(sf::Packet packet, unsigned short remotePort){
	sf::Uint8 type;
	packet >> type;

	if((PacketType)type == STRING){
		std::string message;
		packet >> message;
		//check that message is not an empty string
		if(!message.empty()){
			serverModel->addChatMessage(message); // add new message to m_serverChatHistory
			serverModel->updateModel();
			sf::Packet newPacket;
			newPacket << type << message;
			broadcast(newPacket, remotePort);
		}
	}

	else if((PacketType)type == INTEGER){
		int integer;
		packet >> integer;
		std::cout << integer << std::endl;
	}
	else if((PacketType)type == IMAGE){
		//packet >> *serverModel->getImage(); //starting the view will turn off the server. Only use for testing!
		listen = false; 
	}
	else if((PacketType)type == SINGLEPIXELCOMMAND){
        SinglePixelCommand* command = new SinglePixelCommand();
		packet >> *command;
        std::unique_ptr<Command> pixel(command);
        std::unique_ptr<Command> pixelClone(pixel->clone());
		pastCommands.push_back(*dynamic_cast<SinglePixelCommand*>(pixelClone.get()));
		//serverModel->addRemoteCommand(std::move(pixel));
		//serverModel->updateModel();
		sf::Packet newPacket;
		newPacket << type << *dynamic_cast<SinglePixelCommand*>(pixelClone.get());
		broadcast(newPacket, remotePort);
	}
    else if((PacketType)type == BULKCOMMANDS){
        sf::Uint32 numCommands = 0;
        packet >> numCommands;

        sf::Packet outPacket;
        outPacket << type << numCommands;

        for (int i = 0; i < numCommands; i++) {
            SinglePixelCommand* command = new SinglePixelCommand();
            packet >> *command;
            std::unique_ptr<Command> pixel(command);
            std::unique_ptr<Command> pixelClone(pixel->clone());
			pastCommands.push_back(*dynamic_cast<SinglePixelCommand*>(pixelClone.get()));
            //serverModel->addRemoteCommand(std::move(pixel));
            outPacket << *dynamic_cast<SinglePixelCommand*>(pixelClone.get());
        }
        //serverModel->updateModel();
        broadcast(outPacket, remotePort);

    }
	else if((PacketType)type == CLIENT_TO_SERVER_INIT){
		std::string username;
		sf::Uint32 ip;
		unsigned short videoPort;
		unsigned short audioPort;
		packet >> username >> ip >> videoPort >> audioPort;
		sf::IpAddress clientIp = sf::IpAddress(ip);
		std::cout << username << " connected from IP " << clientIp.toString() << " video UDP port " 
		<< videoPort << " and audio UDP port " << audioPort << std::endl;
		std::tuple<std::string,std::string, unsigned short, unsigned short> newClient = std::make_tuple(username, clientIp.toString(), videoPort, audioPort);
		udpClients.insert(udpClients.begin(), newClient);
		sf::Packet response;
		response << sf::Uint8(PacketType::SERVER_TO_CLIENT_INIT);
		sendPacketToClient(response, remotePort);
		sendAllPastCommands(remotePort);
	}
	else if((PacketType)type == TCP_VIDEO){
		packet << sf::Uint8(type);
		broadcast(packet,remotePort);
	}
	if((PacketType)type == TCP_AUDIO){
		packet << sf::Uint8(type);
		broadcast(packet,remotePort);
	}
	else if((PacketType)type == CLEAR){
		int r,g,b;
		packet >> r >> g >> b;
		sf::Packet newPacket;
		newPacket << type << r << g << b;
		broadcast(newPacket, remotePort);
		
	}
}

//Uses remotePort as a unique identifier in order to send a packet to all clients except one. 
void Server::broadcast(sf::Packet packet, unsigned short remotePort){
	for(std::vector<sf::TcpSocket*>::iterator it = TcpClients.begin(); it != TcpClients.end(); ++it) {
		sf::TcpSocket& client = **it;
		if(remotePort==client.getRemotePort()){
			continue;
		} 
		else {
			client.send(packet);
		}
	}
}

void Server::broadcastAudio(sf::Packet packet, unsigned short remotePort){
	for(std::vector<sf::TcpSocket*>::iterator it = TcpAudioClients.begin(); it != TcpAudioClients.end(); ++it) {
		sf::TcpSocket& client = **it;
		if(remotePort==client.getRemotePort()){
			continue;
		} 
		else {
			client.send(packet);
		}
	}
}

void Server::relayUDPVideo(sf::Packet& packet, std::string clientId){
	for(std::vector<std::tuple<std::string,std::string, unsigned short, unsigned short>>::iterator it=udpClients.begin();
	it != udpClients.end(); ++it) { //iterate through our list of UDP clients
		std::tuple<std::string,std::string, unsigned short, unsigned short>& udpClient = *it; //for each client
		if(std::get<0>(udpClient) != clientId){ //if that client's id does not equal the one passed into this function
			udp.send(packet,sf::IpAddress(std::get<1>(udpClient)),std::get<2>(udpClient)); //send the packet to that client at their IP and port.
		}
	}
}

void Server::sendAllPastCommands(unsigned short remotePort){
	sf::Uint8 header = SINGLEPIXELCOMMAND;
	for(std::vector<SinglePixelCommand>::iterator it=pastCommands.begin(); it != pastCommands.end(); ++it){
		sf::Packet packet;
		SinglePixelCommand command = *it;
		packet << header << command;
		sendPacketToClient(packet,remotePort);
	}
}


void Server::sendPacketToClient(sf::Packet packet, unsigned short remotePort){
	for(std::vector<sf::TcpSocket*>::iterator it = TcpClients.begin(); it != TcpClients.end(); ++it){
		sf::TcpSocket& client = **it;
		if(remotePort==client.getRemotePort()){
			client.send(packet);
			return;
		}
	}
}


void Server::loop(){
	std::cout << "Starting Server, waiting for clients to connect..." << std::endl;
    //Waits for new clients to connect and connects them. Once connected, add their socket to the socket selector and
    //add them to our list of clients. 
    while(listen){
        if(selector.wait()) { //when selector.wait() returns true, a socket has data waiting to be recieved. 
        //If the socket that is ready is the listener, a new client is waiting to connect.
        //Connect the client by creating a new socket and adding that socket to our list of sockets.
            if(selector.isReady(listener)){
                sf::TcpSocket* client = new sf::TcpSocket;
                if (listener.accept(*client) == sf::Socket::Done){
                    // Add the new client to the clients list
                    std::string clientIPaddress = client->getRemoteAddress().toString();
                    int clientPort = client->getRemotePort();
                    std::cout<<"A new client connected from IP: " << clientIPaddress << "\tPort: " << clientPort << std::endl;
                    TcpClients.push_back(client);
                    // Add the new client to the selector so that we will
                    // be notified when he sends something
                    selector.add(*client);
                }
                else {
                    std::cout << "Error, connection failed." << std::endl;
                    delete client;
                }
            } else if(selector.isReady(audioListener)){
                sf::TcpSocket* client = new sf::TcpSocket;
                if (audioListener.accept(*client) == sf::Socket::Done){
                    // Add the new client to the clients list
                    std::string clientIPaddress = client->getRemoteAddress().toString();
                    int clientPort = client->getRemotePort();
                    std::cout<<"Client connected audio from IP: " << clientIPaddress << " Port: " << clientPort << std::endl;
                    TcpAudioClients.push_back(client);
                    sf::TcpSocket* clientForSendingAudio = new sf::TcpSocket;
                    clientForSendingAudio->connect(clientIPaddress, AUDIO_RECEIVE_LISTEN_PORT);
                    TcpAudioClientsForReceiver.push_back(clientForSendingAudio);
                    // Add the new client to the selector so that we will
                    // be notified when he sends something
                    selector.add(*client);
                }
                else {
                    std::cout << "Error, connection failed." << std::endl;
                    delete client;
                }
            } 
            //This handles when a client has sent data to the server. i.e. the socket recieving data is NOT the listener. 
            else {
            //iterate through all clients
                for (std::vector<sf::TcpSocket*>::iterator it = TcpAudioClients.begin(); it != TcpAudioClients.end(); ++it) {
                    sf::TcpSocket& client = **it;
                    if (selector.isReady(client)) { //if this socket is the one that has data ready to be recieved...
                        sf::Packet packet;
                        if (client.receive(packet) == sf::Socket::Done) { //deal with the packet. 
                            //Each client has an audiReciever thread waiting to play audio traffic sent from the server.
                            //When an audio packet is recieved from the clientController, the server will broadcast that packet to all clientAudioStreamRecievers,
                            //except the clientAudioStreamReceiver with the same IP as the clientController.
                            for (std::vector<sf::TcpSocket*>::iterator it = TcpAudioClientsForReceiver.begin(); it != TcpAudioClientsForReceiver.end(); ++it) {
                                sf::TcpSocket& clientAudioStreamReceiver = **it;
                                if(client.getRemoteAddress() != clientAudioStreamReceiver.getRemoteAddress()){
                                    clientAudioStreamReceiver.send(packet);
                                }
                            }
                        }
                    }
                }

                for (std::vector<sf::TcpSocket*>::iterator it = TcpClients.begin(); it != TcpClients.end(); ++it) {
                    sf::TcpSocket& client = **it;
                    if (selector.isReady(client)) { //if this socket is the one that has data ready to be recieved...
                        sf::Packet packet;
                        if (client.receive(packet) == sf::Socket::Done) { //deal with the packet. 
                            parsePacket(packet, client.getRemotePort());
                        }
                    }
                }
            }

        }
        sf::Packet packet;
        unsigned short remotePort;
        sf::IpAddress sender;
        if(udp.receive(packet,sender, remotePort)==sf::Socket::Done) {
            sf::Uint8 header;
            std::string clientId;
            packet >> header >> clientId;
            std::string tempId = clientId;
            packet << clientId;
            packet << header;
            PacketType type = (PacketType)header;
            if(type == UDP_VIDEO){
                relayUDPVideo(packet, tempId);
            }
        }
    }
}

int Server::getNumTcpClient() {
    return TcpClients.size();
}