#include <map>
#include "SinglePixelCommand.hpp"
#include <iostream>

SinglePixelCommand::SinglePixelCommand(sf::Vector2i coordinates, sf::Color color) {
    m_xCoord = coordinates.x;
    m_yCoord = coordinates.y;
	m_color = color.toInteger();
	m_previousColor = sf::Color::White.toInteger(); //set as white by default. 
}

SinglePixelCommand::SinglePixelCommand(){
	m_packetType = SINGLEPIXELCOMMAND;
}

// If the pixel is somewhere in the image, save its old color to m_previousColor and change it m_color. Retrun true on success.
// Checking for out of bounds is handled on the Controller side so no extra Commands are created.
bool SinglePixelCommand::execute(sf::Image* image){
    if (m_xCoord < 0 || m_yCoord < 0 || m_xCoord >= image->getSize().x || m_yCoord >= image->getSize().y){
        return false;
    }
	m_previousColor = image->getPixel(m_xCoord, m_yCoord).toInteger();
    // If the color you're trying to draw is the same as the canvas color, do nothing since it's a no-op.
    if (m_previousColor == m_color) {
        return false;
    }
	image->setPixel(m_xCoord, m_yCoord, sf::Color(m_color));
	return true;
}

std::optional<std::unique_ptr<Command>> SinglePixelCommand::undo(sf::Image* image){
    // Check if someone else has drawn over this pixel
    if (image->getPixel(m_xCoord, m_yCoord).toInteger() != m_color) {
        return std::nullopt;
    }
    image->setPixel(m_xCoord, m_yCoord, sf::Color(m_previousColor));
    return std::unique_ptr<Command>(new SinglePixelCommand(sf::Vector2i(m_xCoord, m_yCoord), sf::Color(m_previousColor)));
}

std::optional<std::unique_ptr<Command>> SinglePixelCommand::redo(sf::Image* image){
    // Check if someone else has drawn over this pixel
    if (image->getPixel(m_xCoord, m_yCoord).toInteger() != m_previousColor) {
        return std::nullopt;
    }
    image->setPixel(m_xCoord, m_yCoord, sf::Color(m_color));
    return std::unique_ptr<Command>(new SinglePixelCommand(sf::Vector2i(m_xCoord, m_yCoord), sf::Color(m_color)));
}

sf::Uint8 SinglePixelCommand::getPacketType() const {
	return sf::Uint8(m_packetType);
}

sf::Color SinglePixelCommand::getColor() const {
	return sf::Color(m_color);
}

sf::Color SinglePixelCommand::getPreviousColor() const {
	return sf::Color(m_previousColor);
}

sf::Vector2i SinglePixelCommand::getCoordinates() const {
	return sf::Vector2i(m_xCoord, m_yCoord);
}

std::string SinglePixelCommand::toString() const {
    const std::map<int, std::string> colorMap {
        {255, "Black"},
        {4294967295, "White"},
        {4278190335, "Red"},
        {16711935, "Green"},
        {65535, "Blue"},
        {4294902015, "Yellow"},
        {4278255615, "Magenta"},
        {16777215, "Cyan"},
        {0, "Transparent"}
    };
	return "SinglePixelCommand: (" + std::to_string(m_xCoord) + ", " + std::to_string(m_yCoord) + ", " + colorMap.at((int)m_color) + ", " + colorMap.at((int)m_previousColor) + ")";
}

std::unique_ptr<Command> SinglePixelCommand::clone() const {
    std::unique_ptr<SinglePixelCommand> clone = std::make_unique<SinglePixelCommand>(sf::Vector2i(m_xCoord, m_yCoord), sf::Color(m_color));
    clone->m_previousColor = m_previousColor;
    return clone;
}

SinglePixelCommand::~SinglePixelCommand(){

}