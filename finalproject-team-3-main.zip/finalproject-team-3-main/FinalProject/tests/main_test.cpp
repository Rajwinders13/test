/** 
 *  @file   main_test.cpp 
 *  @brief  Unit Tests for our program
 *  @author SleepOnIt
 *  @date   11-17-2021 
 ***********************************************/

#define CATCH_CONFIG_MAIN
#include "catch_amalgamated.hpp"

#// Include our Third-Party SFML header
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>             
// Include standard library C++ libraries.
#include <iostream>
#include <string>
#include <string.h> // for memset
#include "Server.hpp"
#include "Model.hpp"
#include "WindowView.hpp"
#include "Controller.hpp"
#include "Model.hpp"
#include "App.hpp"
#include "PacketType.hpp"
#include "SinglePixelCommand.hpp"
#include "MathUtility.hpp"
#include <thread>
#include <future>
#include <unistd.h>

//Global Variables for Canvas for testing purposes
int CANVAS_WIDTH = 1280;
int CANVAS_HEIGHT = 720;

//Global Variables for client/server for testing purposes
std::string SERVER_IP = "127.0.0.1";
int LISTEN_PORT = 2001;
int AUDIO_LISTEN_PORT = 2002;
int AUDIO_LISTEN_RECEIVER_PORT = 2003;

// Helper math functions for testing

int radius = 5;
std::vector<sf::Vector2i> circle_template = MathUtility::BresenhamCircleAlgo(radius);

std::vector<sf::Vector2i> GetCircleTemplate(sf::Uint32& radius) {
    return circle_template;
}

std::vector<sf::Vector2i> UseCircleTemplate(sf::Vector2i& coord, std::vector<sf::Vector2i>& circle_template) {
    int x0 = coord.x;
    int y0 = coord.y;
	std::vector<sf::Vector2i> transformedCircle;
    // Reserve memory in vector to get 4x performance: https://github.com/facontidavide/CPP_Optimizations_Diary/blob/master/docs/reserve.md 
    transformedCircle.reserve((circle_template.size()*8));
    // Use std::transform to shift the circle template by (x,y)
    std::transform(circle_template.begin(), circle_template.end(), std::back_inserter(transformedCircle),
    	[x0,y0](sf::Vector2i p) {
    		return sf::Vector2i(p.x + x0, p.y + y0);
    	});
    return transformedCircle;
}

std::vector<std::unique_ptr<SinglePixelCommand>> simulateLine(sf::Vector2i& current, sf::Vector2i& previous, sf::Color& color, sf::Uint32& radius) {
    std::vector<std::unique_ptr<SinglePixelCommand>> extractedPixels;

    // A circle template drawn at (0,0)
    std::vector<sf::Vector2i> circle_template = GetCircleTemplate(radius);
    // The circle template shifted by (x,y)
    std::vector<sf::Vector2i> all_current = UseCircleTemplate(current, circle_template);
    std::vector<sf::Vector2i> all_previous = UseCircleTemplate(previous, circle_template);

    // Connect the dots
    for (int i=0; i<all_current.size(); i++) {
        std::vector<sf::Vector2i> intermediate_coords = MathUtility::ExtremelyFastLineAlgo(all_previous[i], all_current[i]);
        for (int j=0; j<intermediate_coords.size(); j++) {
            // std::unique_ptr<SinglePixelCommand> pixel(new SinglePixelCommand(intermediate_coords[j], color));
            std::unique_ptr<SinglePixelCommand> pixel = std::make_unique<SinglePixelCommand>(intermediate_coords[j], color);
            extractedPixels.push_back(std::move(pixel));
        }
    }
    return extractedPixels;
}

// ***************** Catch2 Tests *************************************************************************************

TEST_CASE("Test Init Server") {
	Server* server = new Server(LISTEN_PORT, AUDIO_LISTEN_PORT, AUDIO_LISTEN_RECEIVER_PORT, CANVAS_WIDTH, CANVAS_HEIGHT); 
	REQUIRE(server);
}

TEST_CASE("Test Init App Client") {
	App* app = new App(CANVAS_WIDTH, CANVAS_HEIGHT, SERVER_IP, AUDIO_LISTEN_PORT);
	REQUIRE(app);
}

TEST_CASE("Test Controller Init") {
	Controller *c_controller = new Controller();
	REQUIRE(c_controller);
}

TEST_CASE("Test Model Init") {
	Model* m_model = new Model(CANVAS_WIDTH, CANVAS_HEIGHT);
	REQUIRE(m_model);
}


TEST_CASE("Test String Packet"){
	sf::Packet packet;
	std::string testMsg = "Test";
	PacketType type = STRING;
	packet << sf::Uint8(type) << testMsg; 
	
	sf::Uint8 resultType;
	packet >> resultType;
	if((PacketType)resultType == STRING){
		std::string resultMsg;
		packet >> resultMsg;
		REQUIRE(resultMsg == "Test");
	}

}

TEST_CASE("Test Int Packet"){

	sf::Packet packet;
	int testInt = 2;
	PacketType type = INTEGER;
	packet << sf::Uint8(type) << sf::Int32(testInt); 
	
	sf::Uint8 resultType;
	packet >> resultType;
	if((PacketType)resultType == INTEGER){
		int res = 0;
		packet >> res;
		REQUIRE(res == 2);
	}
	
}

TEST_CASE("Test Model Set Username") {
	int model_tests = 0;
	Model* m_model = new Model(CANVAS_WIDTH, CANVAS_HEIGHT);
	std::string test = "test";
	m_model->setUserName(test);

	if(m_model->m_clientUsername=="test"){
		model_tests++;
	}

	REQUIRE(model_tests == 1);
}



TEST_CASE("Test Clear Command") {
	int clear_tests = 0;
	sf::Vector2i coor;
	sf::Image* test = new sf::Image;
	test->create(CANVAS_WIDTH, CANVAS_HEIGHT,sf::Color::White);
	test->create(CANVAS_WIDTH, CANVAS_HEIGHT,sf::Color::Blue);
	sf::Color temp = test->getPixel(1,1);
	if(temp == sf::Color::Blue){
		clear_tests++;
	}
	REQUIRE(clear_tests==1);
	
}

TEST_CASE("Draw thick lines") {
    sf::Image* image = new sf::Image();
    image->create(CANVAS_WIDTH, CANVAS_HEIGHT, sf::Color::White);

    sf::Vector2i currentPoint = sf::Vector2i(10,10);
    sf::Vector2i previousPoint = sf::Vector2i(15,15);

    sf::Color testColor = sf::Color::Red;
    sf::Uint32 testRadius = 5;
    std::vector<std::unique_ptr<SinglePixelCommand>> extractedPixels = simulateLine(currentPoint, previousPoint, testColor, testRadius);
    // Verify that the selected coordinates are White before drawing
    for (int i=0; i<extractedPixels.size(); i++) {
        sf::Vector2i pixelCoord = extractedPixels[i]->getCoordinates();
        sf::Color pixelColor = image->getPixel(pixelCoord.x, pixelCoord.y);
        REQUIRE(pixelColor == sf::Color::White);
    }
    // Now set the pixel to the image
    for (auto& pixel : extractedPixels) {
        image->setPixel(pixel->m_xCoord, pixel->m_yCoord, sf::Color(pixel->m_color));
    }
    // Verify that the selected coordinates are Red after drawing
    for (int i=0; i<extractedPixels.size(); i++) {
        sf::Vector2i pixelCoord = extractedPixels[i]->getCoordinates();
        sf::Color pixelColor = image->getPixel(pixelCoord.x, pixelCoord.y);
        REQUIRE(pixelColor == testColor);
    }
}

