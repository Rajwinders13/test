/** 
 *  @file   VideoChat.hpp 
 *  @brief  VideoChat Interface
 *  @author Team Sleep On It
 *  @date   2021-12-14
 ***********************************************/

#ifndef VIDEOCHAT_HPP
#define VIDEOCHAT_HPP

#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>
#include <mutex>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <PacketType.hpp>
#include <SFML/Network.hpp>

/*! \brief Class responsible for handling video packets and streaming
*/
class VideoChat{
private:

// Member variables For displaying the local webcam with SFML:
cv::VideoCapture cap; //this is the webcam capture object
cv::Mat m_cameraFrame; //the webcam loads data into this matrix
cv::Mat m_sfml_rgba_frame; //this matrix is in a format that SFML understands
sf::Image m_webcamImage; //Image created from the m_sfml_rgba_frame. This image will be displayed on the screen.
sf::Texture m_webcamTexture; //image loaded into texture for faster rendering
sf::Sprite m_webcamSprite; //this sprite has the webcamTexture as its texture. We draw this sprite to the screen.

// This is used to determine which data to load into a UDP packet.
sf::Uint16 m_currentRow = 0;

public: 

/*! \brief Width and height of the space that we can draw 4 webcam windows to.
    @param canvasWidth
    @param canvasHeight
    @param widthOffset
    @param heightOffset 
*/
VideoChat(int canvasWidth, int canvasHeight, int widthOffset, int heightOffset); 

// The resolution of the webcam images to display. 
int camWidth = 320;
int camHeight = 180;
// The boxes in the window to display the webcam are set to be widthOffset by heightOffset. Need to scale up/down the
// Cam width/height so they are equal. 
int scale = 2; 

// This image will be read from by the secondary thread to send data to the server. 
// It should be updated from the main thread.
// The reading and updating functions must both share the same mutex. 
sf::Image m_bufferedWebcam; //use this in secondary thread. 

/*! \brief Call this from main thread.
*/
void moveVideoBuffersToWindowSprites(); 

std::string m_clientUsername; //should be a copy of what's in the model. Put into UDP packets to identify the sender. 

/*! \brief Function to load an image of the local webcam 
*/
void loadBufferedImageOfLocalWebcam();

//The name of the remote client associated with the image being displayed on the screen.
std::string m_client1Name = "empty";
//Buffered image will be changed by the network.
sf::Image m_bufferedImage1;
//Remote Image will be displayed on the screen via the texture and the sprite.
sf::Image m_remoteImage1;
sf::Texture m_remoteTexture1;
sf::Sprite m_remoteSprite1;

std::string m_client2Name = "empty";
sf::Image m_remoteImage2;
sf::Image m_bufferedImage2;
sf::Texture m_remoteTexture2;
sf::Sprite m_remoteSprite2;

std::string m_client3Name = "empty";
sf::Image m_remoteImage3;
sf::Image m_bufferedImage3;
sf::Texture m_remoteTexture3;
sf::Sprite m_remoteSprite3;

/*! \brief Render webcam display on canvas window
*/

void drawVideoFeed(sf::RenderWindow* window);


/*! \brief Parse incoming video packets
Take a packet and change pixels in the corresponding remote client's buffered image based on the data in that client. <br>
It can also assign names to clients if it's the first time that name has been encountered. <br>
There are empty name parameters.
*/
void parsePacket(sf::Packet& packet);

/*! \brief 
Each time this function is called, it will return a UDP packet that has the row value and the colors of the pixels in that row.
If you call this camHeight times, the data for an entire image will be sent.
*/
sf::Packet getNextPacket();

/*! \brief 
Each time this function is called, it will return a TCP packet
*/
sf::Packet getTcpPacket();

};

#endif