/** 
 *  @file   PacketType.hpp 
 *  @brief  Packet Type Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-01
 ***********************************************/
#ifndef PACKETTYPE_HPP
#define PACKETTYPE_HPP

/*! \brief This enum will be the first thing loaded into each packet before it is sent,
And it will be the first thing extracted from each packet before it is read. 
*/
enum PacketType {STRING, IMAGE, INTEGER, SINGLEPIXELCOMMAND, BULKCOMMANDS,
CLIENT_TO_SERVER_INIT, SERVER_TO_CLIENT_INIT, UDP_VIDEO, UDP_AUDIO, TCP_VIDEO,
TCP_AUDIO, CLEAR};



#endif