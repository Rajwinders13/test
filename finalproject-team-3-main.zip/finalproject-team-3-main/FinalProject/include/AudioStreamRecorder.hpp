/** 
 *  @file   AudioStreamRecorder.hpp 
 *  @brief  Audio  Recording Class Interface
 *  @author Team Sleep On It
 *  @date   yyyy-dd-mm 
 ***********************************************/

#ifndef AUDIO_STREAM_RECORDER_HPP
#define AUDIO_STREAM_RECORDER_HPP

#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <iostream>

//referenced sfml/voip github page for this code.

const sf::Uint8 clientAudioData   = 1;
const sf::Uint8 clientEndOfStream = 2;

/*! \brief 
Customised class to record audio and send it over the network
*/
class AudioStreamRecorder : public sf::SoundRecorder {
public:
    /*! \brief 
    Class Constructor
    */

    AudioStreamRecorder(const sf::IpAddress&, unsigned short);
    /*! \brief 
        Class Destructor
    */
    ~AudioStreamRecorder();
    
    /*! \brief 
        This method will launch the client and start recording the audio data.
    */
    void connectAudioRecorder();

private:

    /*! \brief 
    Method which will be called on the start of recording
    */
    virtual bool onStart();

    /*! \brief 
    Method to process samples
    */
    virtual bool onProcessSamples(const sf::Int16* samples, std::size_t sampleCount);

    /*! \brief 
    Method to be called on stopping the recording
    */
    virtual void onStop();

    //Member Variables
    sf::IpAddress  m_host;   ///< Address of the remote host
    unsigned short m_port;   ///< Remote port
    sf::TcpSocket m_socket; ///< Socket used to communicate with the server
};
#endif