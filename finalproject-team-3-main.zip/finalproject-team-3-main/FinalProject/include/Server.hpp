/** 
 *  @file   Server.hpp 
 *  @brief  Server Interface
 *  @author Team Sleep On It
 *  @date   2021-12-14
 ***********************************************/

#ifndef SERVER_HPP
#define SERVER_HPP

#include <SFML/Network.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <iostream>
#include <string>
#include <list>
#include <thread>
#include "PacketType.hpp"
#include "Model.hpp"
#include "WindowView.hpp"
#include "Controller.hpp"
#include "SinglePixelCommand.hpp"
#include <SFML/System.hpp>

/*! \brief Class responsible for establishing the connection between clients
*/
class Server{
private:
	//Selector will hold all of our TCP sockets (including the listener socket that will wait for incoming connections)
	sf::SocketSelector selector;
	//Listener will wait for incoming connections.
	sf::TcpListener listener;
	//This listener will wait for incoming audio connections.
	sf::TcpListener audioListener;
	//This listener will wait for connections to hear the aound.
	sf::TcpListener audioReceiverListener;
	//Once a listener detects an incoming connection, a new socket will be created and added to this list of sockets. 
	//Each entry in the list will be a socket for two way communication between client/server. 
	std::vector<sf::TcpSocket*> TcpClients;

	//To communicate audio over the network we need seperate TCP sockets 
	//Each entry in the list will be a socket for two way communication of audio between client and the server
	std::vector<sf::TcpSocket*> TcpAudioClients;

	std::vector<sf::TcpSocket*> TcpAudioClientsForReceiver;

	std::vector<SinglePixelCommand> pastCommands;

	//This UDP socket will listen for and send UDP Packets related to video and audio chat. 
	sf::UdpSocket udp;

	//This is a list of all connected clients and the the UDP ports they are listening for traffic on. 
	//The first string is a unique client ID, obtained from the client. The program will break if the names are not unique, sorry.
	//The second string is the IP address of that client. 
	//The first unsigned short is the port that they are sending/recieving video traffic on.
	//The second unsigned short is the port that they are sending/recieving audio traffic on. 
	std::vector<std::tuple<std::string,std::string, unsigned short, unsigned short>> udpClients;

	//Resolution of the model. 
	int CANVAS_WIDTH;
	int CANVAS_HEIGHT;
	
	//server will store its own model. This model will be identical to a client model. 
	Model* serverModel; 

	//for testing
	WindowView* serverView; //serverView only used for testing. Because the server is handling network requests on the main thread, it won't also display a view. 
	Controller* serverController; //serverController only used for testing, since it doesn't need to collect userInput or display anything from the model.

public:
	/** @brief  Server Constructor
	 */
	Server(int listenPort, int audioListenPort, int audioRecieverListenPort, int canvasWidth, int canvasHeight);

	/** @brief  Server Class Constructor
	 */
    ~Server();

	//port that the server is using to wait for incoming connections.
	int LISTEN_PORT;

	//port that the server is using to wait for incoming audio connections.
	int AUDIO_LISTEN_PORT;
	
	//port that the server is using to wait for audio recieve connections.
	int AUDIO_RECEIVE_LISTEN_PORT;

	void sendAllPastCommands(unsigned short port);

	/** 
     * @brief The main server loop that listens for new clients and distributes packets to all connected clients.
     * 1. Listens for incoming clients. Once connected, a new socket will be created and added to the clients list. <br>
     * 2. Iterates through all clients. If there is a packet to recieve, call parsePacket() on it and handle appprpriately.
	 */
	void loop();

	// If listen is ever set to fasle, the server loop will stop. 
	bool listen = true;

	/** @brief  
	 Takes a packet and inspects its header. Depending on what the packet has in its header, this function
	 will execute the appropriate function with the rest of the data in the packet. 
	 RemotePort is the socket port on this server of the client that sent the packet originally. It is a unique way
	 to identify which client sent the packet. 
	 */
	void parsePacket(sf::Packet packet, unsigned short remotePort);

	/** @brief
	 * Sends provided packet to all connected clients EXCEPT FOR the sender. The sender is uniquely identified by their remote port.
	 */
	void broadcast(sf::Packet packet, unsigned short remotePort);

	/** @brief
	 * Helper function broadcast function for handling audio
	 */
	void broadcastAudio(sf::Packet packet, unsigned short remotePort);

	/** @brief
	 * Sends a sfml packet to a client
	*/
	void sendPacketToClient(sf::Packet packet, unsigned short remotePort);

	/** @brief
	 * Sends the provided UDP packet to all clients EXCEPT the one with client id.
	 */
	void relayUDPVideo(sf::Packet& packet, std::string clientId);

    /**
     * @brief Get the number of clients currently connected.
     */
    int getNumTcpClient();
};



#endif