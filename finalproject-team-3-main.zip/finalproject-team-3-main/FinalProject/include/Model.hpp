/** 
 *  @file   Model.hpp 
 *  @brief  Model Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-14
 ***********************************************/

#ifndef MODEL_HPP
#define MODEL_HPP

// Include our Third-Party SFML headers
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/System/Vector2.hpp>
#include <iostream>
#include <queue>
#include <stack>
#include <unordered_map>
#include "Command.hpp"
#include "MathUtility.hpp"

/*! \brief Model controls access to m_image. m_image is what the view will display to the screen. 
*/

class Model{
private:
	// Resolution of the model. Set in the constructor. 
	int CANVAS_WIDTH;
	int CANVAS_HEIGHT;
	
	//default background color
	sf::Color BACKGROUND_COLOR = sf::Color::White;

    // Paintbrush member variables
    sf::Color* m_paintbrush_color;
    sf::Uint32* m_paintbrush_radius;
    // Cached circle temples
    inline static std::unordered_map<int, std::vector<sf::Vector2i>> circle_templates;

	//this image is the data that the model protects and controls. 
	sf::Image* m_image;

    void clearRedo();

public:
	Model(int canvasWidth, int canvasHeight); 	//constructor

	/*! \brief getter functions for the view to use
	*/	
	int getWindowWidth();
	int getWindowHeight();

	/*! \brief getter function for image that will be displayed. WARNING exposes the actual m_image in a way that allows it to be mutated. 
		In an ideal world, we wouldn't expose the model to mutation like this.
	*/	
	sf::Image* getImage();

	/*! \brief changes the image in the model to the one provided. WARNING overwrites all previous data.
	*/	
	void setImage(sf::Image* image);

	/*! \brief executes all commands in the m_RemoteCommands and m_localCommands queues. 
	*/	
	void updateModel();

	//Provides the queue of commands that needs to be sent to the server for remote execution. 
	std::queue<std::unique_ptr<Command>> getCommandsForServer();

	/*! \brief 
	Undoes a command if possible. Undo logic:
	//1.) In order to be able to undo a command, one or more commands must be in the m_undo stack. This happens whenever a command is executed locally. 
	//2.) Every command has an undo method that returns a NEW command. This new command is the reverse of what the original command was.
	//3.) This new command will be executed on the local model, but NOT put onto the m_undo stack. Instead, this new command will be put onto the redo stack. 
	//4.) This new command will be sent to the server (i.e. added to the m_commandsToSendToServer queue) and other clients who will execute it as normally. They can treat it like a normal command since they will never have to "undo" it.
	//5.) If we want to redo a command, it must first be in the m_redo stack. When we call redo, a similar process to above will occur. 
	*/	
	int undoCommand();

	/*! \brief 
	//Redoes a command if possible. Redo logic: 
	//1.) In order to be able to redo a command, one ore more commands must be in the m_redo stack.
	//2.) Every command has an undo method that reutnrs a NEW command. This new command is the reverse of what the original command was. In the context of redoing, we are
	//actualing undoing the undo. 
	//3.) This new command will be executed on the local model and put onto the m_undo stack. 
	//4.) This new command will be sent to the server.	
	*/
	int redoCommand();

	/*! \brief 
	Adds a command to the queue of local commands to be executed.
	*/ 
	void addLocalCommand(std::unique_ptr<Command> c);

	/*! \brief 
	Adds a command to the queue of remote commands to be executed. 
	*/ 
	void addRemoteCommand(std::unique_ptr<Command> c);
	
	/*! \brief 
	add a new <string> message to the chat_history vector
	*/ 
	void addChatMessage(std::string message);

	/*! \brief 
	Send a message send to the server to all clients connected
	*/
	bool sendServerMessageToClient(std::string newMessage);

	/*! \brief 
	Set username on App Init
	*/
	void setUserName(std::string username);

	//chat server history vector
	std::queue<std::string> m_localChatHistory;

	//chat server history vector
	std::queue<std::string> m_serverChatHistory;

	//username of the client
	std::string m_clientUsername;

	int getNumPendingCommandsForServer();

    // ********** Drawing member variables **********

	// m_localCommands stores the commands that were generated on the local machine but have yet to be executed.
	std::queue<std::unique_ptr<Command>> m_localCommands;

	// m_undo stores commands that were generated on the local machine and have executed already. 
	std::stack<std::unique_ptr<Command>> m_undo;

	//m_redo stores commands that were generated on the local machine and were "undone"
	std::stack<std::unique_ptr<Command>> m_redo;

	// m_RemoteCommands stores commands that have been sent from the server and have yet to be executed.
	std::queue<std::unique_ptr<Command>> m_remoteCommands;

	// m_commandsToSendToServer contains commands that have been executed locally but still need to be sent to the server. 
	std::queue<std::unique_ptr<Command>> m_commandsForServer;

    // ********** Paintbrush member variables **********

    // Public color codes map
    std::unordered_map<sf::Keyboard::Key, sf::Color> color_codes;
    // Stack that stores the number of undo commands.
    std::stack<int> m_undo_count;
    // Stack that stores the number of redo commands.
    std::stack<int> m_redo_count;
    // Count the number of draw pixels from mouse press to mouse release.
    inline static int drawCount;
    // A vector of previous line commands set to nullptr on init.
    std::unique_ptr<sf::Vector2i> previousCoord;

    // ********** Paintbrush member functions **********

	/*! \brief 
	returns the current paintbrush color
	*/
    sf::Color& GetPaintbrushColor();

	/*! \brief 
	sets color by key num press event 
	*/
    void SetPaintbrushColor(sf::Keyboard::Key key);

	/*! \brief 
	gets and returns the drawing color of the paintbrush
	*/
    sf::Uint32& GetPaintbrushRadius();

	/*! \brief 
	sets the drawing radius of the paintbrush
	*/
    void SetPaintbrushRadius(sf::Uint32 radius);

	/*! \brief 
	Generate and cache a circle template for faster drawing.
	*/
    static std::vector<sf::Vector2i> GetCircleTemplate(sf::Uint32& radius);
    static std::vector<sf::Vector2i> UseCircleTemplate(sf::Vector2i& coord, std::vector<sf::Vector2i>& circle_template);
    void SetCircleTemplate(sf::Uint32 radius);
	
	/*! \brief 
	Set current m_paintbrush_color from GUI Pallete Selector
	*/
	void setColorFromPallete(float red, float green, float blue);

	
};

#endif