#ifndef WINDOWVIEW_HPP
#define WINDOWVIEW_HPP 

#include <opencv2/opencv.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <iostream>
#include <cassert>
#include <cstring>
#include "Model.hpp"
#include "Controller.hpp"
#include "VideoChat.hpp"
#define GL_SILENCE_DEPRECATION // silence OpenGL Warnings
#include <SFML/OpenGL.hpp>
#include <SFML/Window.hpp>

//Explanation of how SFML View works:
//A Sprite is a 2d rectangle. In order for it to show up as anything other than invisible, it needs to have a
//texture on top of it. Whenever the window refreshes, it will draw the sprite, which includes that sprite's texture.
//We can update the colors of a texture with the SFML loadFromImage() function. This function will which will turn 
//an image (an array of RGBA pixel values) into a texture.

/*! \brief Class responsible for handling the view layer of the application including the GUI
*/
class WindowView{
private:

	Model* m_model;
	Controller* m_controller;
	int refreshRate; //used to only update the texture on certain iterations of our program loop. 

	sf::Sprite* m_sprite; //A sprite is a textured rectangle. 
	sf::Texture* m_texture; //A texture is a 2d image that will cover our sprite. 
	sf::RenderWindow* m_window = nullptr; 	//window to display our sprite, which is overlayed by our texture. 

	std::vector<std::string> chat_history; // queue for chat history
    struct nk_context *ctx = nullptr; // create nuklear gui context
	struct nk_colorf *bg;   //create nuklear window backgorund color
	sf::RenderWindow* gui_window;  //create sfml window for nuklear context

public:

	/*! \brief function to handle keyboard presses
	*/
	//constructor will open a window and reserve memory for m_sprite, m_image, and m_texture. 
	WindowView(Model* model, Controller* controller, VideoChat* videoChat, int webcamWidth);
	
	/*! \brief WindowView Class Destructor
	*/
	~WindowView(); 

	VideoChat* m_videoChat;

	/*! \brief initializes our sprite to an empty canvas with the correct background color.
	*/
	void initView(); 
	
	/*! \brief initializes the nuklear context and loads custom font
	*/
	void initGUI(); 
	
	/*! \brief Run GUI draw loop
	*/
	void GUILoop(); 

	/*! \brief Check the m_localChatHistory for new messages
	*/
	void checkForNewMessages(); 
	
	
	/*! \brief Send messages to m_localChatHistory and server
	*/
	void sendMessageToServer(std::string msg, int len); 
	
	/*! \brief Display char array in chat view box
	*/
	bool displayChat(std::string msg); 

	/*! \brief loads whatever our image is currently into the GPU as a texture. 
	*/
	void draw(); 

	/*! \brief Sends user input to the controller
	*/
	void update(); 

	/*! \brief main program loop.
	*/
	void loop(); 

	/*! \brief function to save the current screen shot of the canvas
	*/
	void saveScreenShot(); 

	/*! \brief Check what current tools are seleted within the GUI
	*/
	void checkToolStatus(); 
};


#endif