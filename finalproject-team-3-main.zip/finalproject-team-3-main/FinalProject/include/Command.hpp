/** 
 *  @file   Command.hpp 
 *  @brief  Command Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-01
 ***********************************************/

#ifndef COMMAND_HPP
#define COMMAND_HPP

#include <SFML/Network.hpp>
#include "PacketType.hpp"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <string>
#include <optional>

/*! \brief Command class is something that can change pixels on the canvas. It can undo itself and be sent over the network.
Because it should be able to be sent over the network, it should used the sfml wrapper classes for member variables (e.g. sf::Uint8).
Types of commands are identified by the enum packetType.
*/
class Command{

public:
	/*! \brief 
	Customised class to record audio and send it over the network
	*/
	sf::Uint8 m_packetType;

	/*! \brief 
	Execute changes one or more pixels on the image.
	*/
	virtual bool execute(sf::Image* image) = 0; 

	/**
	 * @brief Undo a pixel on the image
	 * @param image The image that will be changed.
	 * @return unique_ptr or nullopt if the pixel was already changed by another command
	 */
    virtual std::optional<std::unique_ptr<Command>> undo(sf::Image* image) = 0;

	/**
	 * @brief Redo a pixel on the image
	 * @param image The image that will be changed.
	 * @return unique_ptr or nullopt if the pixel was already changed by another command
	 */
    virtual std::optional<std::unique_ptr<Command>> redo(sf::Image* image) = 0;

	/*! \brief 
	Returns the packet type of this command as an Unsigned 8-bit integer. 
	This integer can be cast with the PacketType enum to determine its name. 
	8 bit integers are used to ensure consistent behavior across the network
	and across different systems. 
	*/
	virtual sf::Uint8 getPacketType() const = 0;

    /*! \brief Deep copy of a command.
	*/
    virtual std::unique_ptr<Command> clone() const = 0;

	/*! \brief Print out a description of the command
	*/
    virtual std::string toString() const = 0;

	/*! \brief Destructor.
	*/
	virtual ~Command() {};
};

#endif