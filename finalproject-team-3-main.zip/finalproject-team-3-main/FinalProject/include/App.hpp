/** 
 *  @file   App.hpp 
 *  @brief  App Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-01 
 ***********************************************/

#ifndef APP_HPP 
#define APP_HPP

#include "Server.hpp"
#include "Controller.hpp"
#include "WindowView.hpp"
#include "VideoChat.hpp"
#include "AudioStreamReceiver.hpp"
#include "AudioStreamRecorder.hpp"

   
/*! \brief The app class is an entry into our model, view, and controller from main. 		
*/
class App{
  
private:  
    
    //VideoChat video; // this object will handle video chat. 

    /*! \brief Controller will handle client/server connections and commands. It will get data both from the server and the user and update the model with it.		
    */
    Controller* m_controller; 
    
    /*! \brief This object will consult the model for what to display on the SFML render window. It has the main program loop that updates the screen and captures user input. 		
    */
    WindowView* m_view; 
    
    /*! \brief this object will store the sf::Image and write that to an sf::RenderWindow 		
    */
    Model* m_model; 
    VideoChat* m_videoChat; 
	int WEBCAM_WIDTH_OFFSET = 640; //the window will be constructed to be the width of the canvas PLUS the width of the webcam image
	int WEBCAM_HEIGHT_OFFSET = 360;
    AudioStreamReceiver* audioReceiver;
	AudioStreamRecorder* audioRecorder;

public:
    /*! \brief Constructor and Destructor
    */
    App(int canvasWidth, int canvasHeight, std::string ipAddress, int audioListenPort); 
    ~App(); //destructor. 

    /*! \brief  Wrapper function for controller connectToServer. Tries to connect to a server at the specified IP address listening on the provided port. 
    */
    void connectToServer(sf::IpAddress ip, int listenPort, int audioListenPort, int audioListenReceiverPort);

    /*! \brief   The view loop will display the contents of the model on to the screen and collect user input. 
    */
    void startViewLoop();

    /*! \brief pass username to the Model on program init
    */
    void setUserName(std::string user);

     /*! \brief The controller loop will communicate with the server. WARNING: this should run in a separate thread from the view, and assumes that
     the controller is already connected to the server. 
    */
    void startControllerLoop();

    /*! \brief The method to call controller method to start audio recorder
    */
    void startAudioRecorder();

    /*! \brief The method to start the audio receiver
    */
    void startAudioReceiver(unsigned short port);

    void startVideoReceiver();

};

#endif
