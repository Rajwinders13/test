/** 
 *  @file   AudioStreamReciever.hpp 
 *  @brief  Audio Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-01 
 ***********************************************/

#ifndef AUDIO_STREAM_RECIEVER_HPP
#define AUDIO_STREAM_RECIEVER_HPP

//referenced sfml/voip github page for this code.

#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <iterator>

const sf::Uint8 serverAudioData   = 1;
const sf::Uint8 serverEndOfStream = 2;

/*! \brief Customised class to get audio from the network	
*/
class AudioStreamReceiver : public sf::SoundStream {

public:

    /*! \brief Class Constructor
    */
    AudioStreamReceiver();
    
    /*! \brief Method to run the server and play audio data from the client.
    */
    void start(unsigned short);

    /*! \brief This method will launch the server and wait for the incoming data.
    */
    void connectAudioReceiver(unsigned short );
    void receive(sf::Packet);

private:

    /*! \brief Method to get datafrom the sound stream
    */
    virtual bool onGetData(sf::SoundStream::Chunk&);

    /*! \brief Method to get the data at provided time offset
    */
    virtual void onSeek(sf::Time timeOffset);

    /*! \brief THs method will keep getting data from the client until the playback is stopped.
    */
    void receiveLoop();

    //Member Variables
    sf::TcpListener        m_listener;
    sf::TcpSocket          m_client;
    sf::Mutex              m_mutex_receiver;
    std::vector<sf::Int16> m_samples;
    std::vector<sf::Int16> m_tempBuffer;
    std::size_t            m_offset;
    bool                   m_hasFinished;
};

#endif