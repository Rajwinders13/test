/** 
 *  @file   MathUtility.hpp 
 *  @brief  Math utility interface
 *  @author Team Sleep On It
 *  @date   2021-10-23
 ***********************************************/

#ifndef MATHUTILITY_H
#define MATHUTILITY_H

#include <vector>
#include <SFML/System/Vector2.hpp>

/*! \brief A utility class for drawing lines and shapes.
*/
class MathUtility {

public:
    /**
     * @brief Calculate a vector of intermediate coordinates between start and end points.
     * This is the Extremely Fast Line Algorithm (EFLA) Variation E <br>
     * Author: Po-Han Lin (2005) <br>
     * Source: http://www.edepot.com/algorithm.html 
     * @param start starting coordinate (x1,y1)
     * @param end ending coordinate (x2,y2)
     * @return A vector of intermediate coordinates
    */
    static std::vector<sf::Vector2i> ExtremelyFastLineAlgo(const sf::Vector2i& start, const sf::Vector2i& end);

    /**
     * @brief Calculate a vector of coordinates for a filled in circle using a modified version of Bresenham's Circle Algorithm.
     * Cache this circle template so that App does not need to always compute this. <br>
     * Author: Linus Arver (2021) <br>
     * Source: https://funloop.org/post/2021-03-15-bresenham-circle-drawing-algorithm.html
     * @param radius The radius of the circle
     * @return A vector of coordinates for a filled in circle
    */
    static std::vector<sf::Vector2i> BresenhamCircleAlgo(const int radius);
};

#endif