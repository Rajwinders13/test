/** 
 *  @file   SinglePixelCommand.hpp 
 *  @brief  SinglePixelCommand Interface
 *  @author Team Sleep On It
 *  @date   2021-12-14
 ***********************************************/

#ifndef SINGLEPIXELCOMMAND_HPP
#define SINGLEPIXELCOMMAND_HPP

#include "Command.hpp"

/*! \brief
A single pixel command will change the color of a single pixel. When the command is undone, it will change the color
of the pixel back to what it originally was. 
*/
class SinglePixelCommand : public Command {

public:
	// Member Variables. All public sf:: types so they place nicely with packets. 
	sf::Uint8 m_packetType = sf::Uint8(SINGLEPIXELCOMMAND);
	sf::Uint32 m_xCoord;
    sf::Uint32 m_yCoord;
	sf::Uint32 m_color;
	sf::Uint32 m_previousColor;

	/*! \brief SinglePixelCommand default constructor for reading data from packet. 
	*/
	SinglePixelCommand(); 

	/*! \brief SinglePixelCommand Constructor
		@param coordinates, coordinates of the pixel that will be changed
		@param color, color to paint the selected pixel
	*/
	SinglePixelCommand(sf::Vector2i coordinates, sf::Color color); 

	/*! \brief SinglePixelCommand Destructor
	*/
	~SinglePixelCommand(); 

	/** @brief Look inside the packet and get the packet type ENUM
	*/
	sf::Uint8 getPacketType() const override;
	sf::Color getColor() const;
	sf::Color getPreviousColor() const;
	sf::Vector2i getCoordinates() const;

	/**
	 * @brief Changes the color of a single pixel to m_color and saves its previous color in m_previousColor. 
	 * @param image The image that will be changed.
     * @return True if successful, false if not successful
	 */
	bool execute(sf::Image* image) override; 

	/**
	 * @brief Undo a pixel on the image
	 * @param image The image that will be changed.
	 * @return unique_ptr or nullopt if the pixel was already changed by another command
	 */
    std::optional<std::unique_ptr<Command>> undo(sf::Image* image) override;
	
	/**
	 * @brief Redo a pixel on the image
	 * @param image The image that will be changed.
	 * @return unique_ptr or nullopt if the pixel was already changed by another command
	 */
    std::optional<std::unique_ptr<Command>> redo(sf::Image* image) override;

    /**
     * @brief A helper function to deep copy a unique_ptr<SinglePixelCommand>
     * Source: https://stackoverflow.com/questions/39905802/deep-copy-and-dynamic-cast-unique-ptr 
    */
    std::unique_ptr<Command> clone() const override;

	/**
     * @brief Print out a description of the SinglePixelCommand
    */
	std::string toString() const override;
};

#endif
