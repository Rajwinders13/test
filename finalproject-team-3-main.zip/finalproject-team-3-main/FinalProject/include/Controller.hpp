/** 
 *  @file   Controller.hpp 
 *  @brief  Controller Class Interface
 *  @author Team Sleep On It
 *  @date   2021-12-14
 ***********************************************/

#ifndef CONTROLLER_HPP
#define CONTROLLER_HPP

#include <SFML/Network.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <SFML/System/Vector2.hpp>
// Include standard library C++ libraries.
#include <iostream>
#include <string>
#include "Model.hpp"
#include "PacketType.hpp"
#include "Command.hpp"
#include "SinglePixelCommand.hpp"
#include "MathUtility.hpp"
#include <mutex>
#include "VideoChat.hpp"
#include "AudioStreamReceiver.hpp"
#include "AudioStreamRecorder.hpp"


/**
 * @brief The controller class handles communication between the Model (which stores the image), the View (the front end GUI), and the Server.
 * It is able to create packets to send to the server, and handle input packets from the server.
 */
class Controller{
private:
	// Member variables for the local client
	sf::TcpSocket socket;
	sf::TcpSocket audioSocket;
    sf::Socket::Status status;
	sf::Socket::Status audioSocketStatus;
    sf::IpAddress localIP;

    // Member variables for UDP communication
	sf::UdpSocket videoUdp;
	sf::UdpSocket audioUdp;
	std::queue<sf::Packet> m_udpVideoPackets;

	// Each local client holds an a pointer to its Model which stores the image
    Model* m_model;

	// This mutex will be used to protect the model when the server and view are trying to read/write to it at the same time
	std::mutex m_mutex;
	std::mutex m_videoMutex;
	std::mutex m_audioMutex;

    // Member variables for smooth audio playback
	sf::SoundBuffer buffer;
	sf::Sound sound;

    // Member variables for audio
	int m_packetsSentSinceRefresh =0;
	AudioStreamReceiver* m_audioReceiver;
	std::vector<sf::Int16> m_audio_samples;
	bool isPlayBackSet = false;

    // Member variable for video chat
	VideoChat* m_videoChat;

public:
	/**
     * @brief Constructor for the Controller class.
     */
	Controller();

	/**
     * @brief Destructor for the Controller class.
     */
	~Controller();

	/**
     * @brief Set the model we wish to use.
     * Should be called before the controller loop begins.
	*/
	void setModel(Model* model);
	
	/**
     * @brief Set the video chat we wish to use.
     * The controller loop should not run while the view is not open.
	*/
	void setVideoChat(VideoChat* videoChat);

	/*! \brief 	function to stop controller loop
	*/
	void stopControllerLoop();

	/*! \brief Tells the model to take and pending commands in its queue and execute them. 
    * Uses the mutex to make sure that the view and server don't access it while it's updating.  
	*/
	void updateModel();

	/*! \brief This loop will collect pending local Commands from the model that need to be sent to the server and send them.
    * It will also collect Commands sent from the server and allow the model to execute them. <br>
	* It uses the mutex so that the view does not access the model while the data is being accessed by the networking functions.  
	*/
	void loop();

    bool viewRunning = true;
	
    /**
     * @brief If you have to ask what this is doing, you're in trouble
     */
    void getThreadsafeCommandsForServer();
	std::queue<std::unique_ptr<Command>> threadsafeCommandsForServer;
    int popCount = 0;

	/*! \brief This loop will collect video UDP packets from the network and add them to the m_udpVideoPackets<Packet*>  queue for later
	*/
	void videoReceiveLoop();

	// Networking stuff
	std::string serverIP;

    /**
     * @brief Connect a client to a server upon initialization.
     * Provides networking information back to the client after connecting.
     * @param Address The IP address of the server.
     * @param ListenPort The port on the server to listen to.
     * @param audioListenPort The port on the server to send out audio.
     * @param audioListenRecieverPort The port on the server to receive in audio.
     */
	bool connectToServer(sf::IpAddress Address, int ListenPort, int audioListenPort, int audioListenReceiverPort);

    /**
     * @brief Send a packet that contains a string to the server
     * @param packetType The type of packet to send
     */
	bool sendStringToServer(std::string string);

    /**
     * @brief Send a packet that contains an integer to the server
     * @param int The integer to send
     */
	bool sendIntegerToServer(int integer);

    /**
     * @brief Send a packet that contains an image to the server
     * @param image The image to send
     */
	bool sendImageToServer(sf::Image image);

    /**
     * @brief Send a packet that contains a SinglePixelCommand to the server
     * @param command The SinglePixelCommand to send
     */
	bool sendSinglePixelCommandToServer(SinglePixelCommand& command);

    /**
     * @brief Send a packet that contains a bulk amount of SinglePixelCommands to the server
     * @param bulkCommands A vector of SinglePixelCommands
     * @param bulkSize The size of the bulkCommands vector which will be inserted into a packet
     */
    bool sendBulkCommmandsToServer(std::vector<SinglePixelCommand>& commands, int numCommands);

    /**
     * @brief Tell the server to broadcast a new packet out to all clients
     */
    void sendCommandData();

    /**
     * @brief Send a clear command out to all clients if the spacebar is pressed by anyone
     * @param newColor The new color to set the canvas color to
     */
	bool sendClearCommandToServer(sf::Color newColor);

    /**
     * @brief Parse an incoming packet and add it to the local client's queue of commands
     * @param packet The incoming packet to parse
     */
	void parsePacket(sf::Packet packet);

    /**
     * @brief Set the audio stream receiver for local clients
     */
	void setAudioReceiver(AudioStreamReceiver* audioReceiver);

    /**
     * @brief Simulate a thick line and get a vector of SinglePixelCommands
     * @param current The (x,y) coordinates of the current mouse position
     * @param previous The (x,y) coordinates of the previous mouse position
     * @param color The current paintbrush color
     * @param radius The current paintbrush radius
     * @return A vector of SinglePixelCommands wrapped in a unique pointer for memory safety
     */
    std::vector<std::unique_ptr<SinglePixelCommand>> simulateLine(sf::Vector2i& current, sf::Vector2i& previous, sf::Color& color, sf::Uint32& radius);
	
	/*! \brief Send video data out to all clients
    * These two functions need a mutex to separate them. 
	*/
	void sendVideoData(int numPackets);

    /**
     * @brief Take the video buffers, which the updateBufferedVideoFramesFromPacket is using and turn those into the sprites that the window can display
     */
	void moveVideoBuffersToWindowSprites();

    /**
     * @brief Update the video buffers after receiving new packets from the server
     */
	void updateBufferedVideoFramesFromPackets();

    /**
     * @brief Mouse clicked down
     */
	void mouseClicked(sf::Vector2i coordinate);

    /**
     * @brief Mouse released up
     */
	void mouseReleased(sf::Vector2i coordinate);

    /**
     * @brief Z key released
     */
	void zReleased();

    /**
     * @brief Y key released
     */
	void yReleased();

    /**
     * @brief R key released
     */
	void rReleased();

    /**
     * @brief Backspace key released
     */
	void backspaceReleased();

    /**
     * @brief Spacebar key released
     */
	void spacebarPressed();

};


//These are overloads for the sf::Packet class so we can send sf::Image over the network. 
sf::Packet& operator >> (sf::Packet& packet, sf::Image& image);
sf::Packet& operator << (sf::Packet& packet, const sf::Image& image);

//These are operator overloads so SinglePixelCommands can be put into/taken out of packets with the >> and << operators. 
sf::Packet& operator >> (sf::Packet& packet, SinglePixelCommand& command);
sf::Packet& operator << (sf::Packet& packet, const SinglePixelCommand& command);

#endif