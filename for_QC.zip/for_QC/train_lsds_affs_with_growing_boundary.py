from funlib.learn.torch.models import UNet, ConvPass
from gunpowder.torch import Train
import gunpowder as gp
import math
import numpy as np
import torch
import logging
import os
from tqdm import tqdm
from lsd.gp import AddLocalShapeDescriptor

torch.backends.cudnn.benchmark = True


logging.basicConfig(level=logging.INFO)

n_samples = 24

data_dir = "/n/groups/htem/users/ras9540/learned_lsds/experiments/epithelial/data/"
zarr_name = "epithelial.zarr"
zarr_path = data_dir + zarr_name
log_dir = "runs/"

# network parameters
num_fmaps = 48
input_shape = gp.Coordinate((156, 156))
output_shape = gp.Coordinate((116, 116))
batch_size = 16  # TODO: increase later

voxel_size = gp.Coordinate((1, 1))  # TODO: change later
input_size = input_shape * voxel_size
output_size = output_shape * voxel_size
context = (input_size - output_size) /2

class ConvertLabels(gp.BatchFilter):

    def __init__(self, in_array, out_array, dtype):
        self.in_array = in_array
        self.out_array = out_array
        self.dtype = dtype

    def setup(self):

        self.provides(
            self.out_array,
            self.spec[self.in_array].copy())
        
    def prepare(self, request):

        deps = gp.BatchRequest()
        deps[self.in_array] = request[self.out_array].copy()

        return deps

    def process(self, batch, request):

        data = batch[self.in_array].data.astype(self.dtype)

        spec = batch[self.in_array].spec.copy()
        spec.roi = request[self.out_array].roi.copy()
        spec.dtype = self.dtype

        batch = gp.Batch()

        array = gp.Array(data, spec)

        batch[self.out_array] = array

        return batch

class LsdAfModel(torch.nn.Module):

    def __init__(self):
        super().__init__()

        self.unet = UNet(
            in_channels=1,
            num_fmaps=num_fmaps,
            fmap_inc_factor=5,
            downsample_factors=[
                [2, 2],
                [2, 2]],
            kernel_size_down=[
                [[3, 3], [3, 3]],
                [[3, 3], [3, 3]],
                [[3, 3], [3, 3]]],
            kernel_size_up=[
                [[3, 3], [3, 3]],
                [[3, 3], [3, 3]]])

        self.lsd_head = ConvPass(num_fmaps, 6, [[1, 1]], activation='Sigmoid')
        self.aff_head = ConvPass(num_fmaps, 2, [[1, 1]], activation='Sigmoid')

    def forward(self, input):

        z = self.unet(input)
        lsds = self.lsd_head(z)
        affs = self.aff_head(z)

        return lsds, affs


class WeightedMSELoss(torch.nn.MSELoss):

    def __init__(self):
        super(WeightedMSELoss, self).__init__()

    def forward(self, lsds_prediction, lsds_target, lsds_weights, affs_prediction, affs_target, affs_weights,):

        loss1 = super(WeightedMSELoss, self).forward(
                lsds_prediction*lsds_weights,
                lsds_target*lsds_weights)

        loss2 = super(WeightedMSELoss, self).forward(
            affs_prediction*affs_weights,
            affs_target*affs_weights)
        
        return loss1 + loss2


def train(iterations):

    raw = gp.ArrayKey('RAW')
    labels = gp.ArrayKey('LABELS')
    converted_labels = gp.ArrayKey('CONVERTED_LABELS')
    affinities = gp.ArrayKey('AFFS')
    affs_mask = gp.ArrayKey('AFFS_MASK')
    affs_weights = gp.ArrayKey('AFFS_WEIGHTS')
    pred_affinities = gp.ArrayKey('PRED_AFFS')
    affs_gradients = gp.ArrayKey('AFFS_GRADIENTS')
    lsds_gradients = gp.ArrayKey('LSDS_GRADIENTS')
    lsds_weights = gp.ArrayKey('LSDS_WEIGHTS')
    gt_lsds = gp.ArrayKey('GT_LSDS')
    pred_lsds = gp.ArrayKey('PRED_LSDS')

    model = LsdAfModel()
    
    loss = WeightedMSELoss()

    optimizer = torch.optim.Adam(lr=1e-5, params=model.parameters())


    request = gp.BatchRequest()
    request.add(raw, input_size)
    request.add(labels, output_size)
    request.add(converted_labels, output_size)
    request.add(affinities, output_size)
    request.add(affs_weights, output_size)
    request.add(affs_gradients, output_size)
    request.add(lsds_gradients, output_size)
    request.add(lsds_weights, output_size)
    request.add(gt_lsds, output_size)


    snapshot_request = gp.BatchRequest()
    snapshot_request[pred_affinities] = request[affinities].copy()
    snapshot_request[pred_lsds] = request[gt_lsds].copy()

    sources = tuple(
            gp.ZarrSource(
                zarr_path,
                {
                    raw: f'train/raw/{i}',
                    labels: f'train/gt_labels/{i}'
                },
                {
                    raw: gp.ArraySpec(interpolatable=True, voxel_size=(1, 1)),
                    labels: gp.ArraySpec(interpolatable=False, voxel_size=(1, 1))
                }) +
                gp.Normalize(raw) +
                gp.Pad(raw, None) +
                gp.Pad(labels, context) +
                gp.RandomLocation()
                for i in range(n_samples)
            )


    # raw:      (h, w)
    # labels:   (h, w)
    # ignore:   (h, w)

    pipeline = sources
    pipeline += gp.RandomProvider()
    pipeline += gp.SimpleAugment()
    pipeline += gp.ElasticAugment(
        control_point_spacing=(64, 64),
        jitter_sigma=(5.0, 5.0),
        rotation_interval=(0, math.pi/2))
    pipeline += gp.IntensityAugment(
        raw,
        scale_min=0.8,
        scale_max=1.2,
        shift_min=-0.2,
        shift_max=0.2)
    pipeline += gp.NoiseAugment(raw, var=0.01)
    pipeline += gp.Squeeze([labels])
    pipeline += ConvertLabels(
        labels,
        converted_labels,
        np.uint64)
    pipeline += gp.GrowBoundary(converted_labels)
    
    pipeline += AddLocalShapeDescriptor(
            converted_labels,
            gt_lsds,
            mask = lsds_weights,
            sigma=10,
            downsample=1)

    pipeline += gp.AddAffinities(
        affinity_neighborhood=[
            [0, -1],
            [-1, 0]],
        labels=converted_labels,
        affinities=affinities,
        affinities_mask=affs_mask,
        dtype=np.float32)


    # raw:          (h, w)
    # affinities:   (2, h, w)
    # affs mask:    (2, h, w)

    pipeline += gp.BalanceLabels(
        affinities,
        affs_weights,
        mask=affs_mask)

    # raw:          (h, w)
    # affinities:   (2, h, w)
    # affs weights: (2, h, w)

    # add "channel" dimensions
    pipeline += gp.Unsqueeze([lsds_weights])

    # raw:          (1, h, w)
    # affinities:   (2, h, w)
    # affs weights: (2, h, w)

    pipeline += gp.Stack(batch_size)

    # raw:          (b, 1, h, w)
    # affinities:   (b, 2, h, w)
    # affs weights: (b, 2, h, w)


    pipeline += gp.PreCache(num_workers=10)

    pipeline += Train(
        model,
        loss,
        optimizer,
        inputs={
            'input': raw
        },
        outputs={
            0: pred_lsds,
            1: pred_affinities
        },
        gradients={
            0: lsds_gradients,
            1: affs_gradients
         },
        loss_inputs={
            0: pred_lsds,
            1: gt_lsds,
            2: lsds_weights,
            3: pred_affinities,
            4: affinities,
            5: affs_weights
        },
        log_dir = log_dir,
        save_every=2000)

    pipeline += gp.Snapshot({
            raw: 'raw',
            labels: 'labels',
            affinities: 'affinities',
            affs_weights: 'affs_weights',
            pred_affinities: 'pred_affinities',
            lsds_gradients: 'lsds_gradients',
            affs_gradients: 'affs_gradients',
            gt_lsds: 'gt_lsds',
            pred_lsds: 'pred_lsds',
            lsds_weights: 'lsds_weights,'
        },
        every=5000,
        output_filename='{iteration}.zarr',
        additional_request=snapshot_request)
    
    pipeline += gp.PrintProfilingStats(every=10)

    with gp.build(pipeline):
        for i in tqdm(range(iterations)):
            pipeline.request_batch(request)

if __name__ == '__main__':

    train(1000000)
